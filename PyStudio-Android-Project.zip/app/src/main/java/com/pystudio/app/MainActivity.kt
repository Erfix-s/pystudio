package com.pystudio.app

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File

class MainActivity : ComponentActivity() {

    lateinit var web: WebView
    private lateinit var runtime: PyRuntime

    private var pendingPickId = ""
    private var pendingPickMode = ""
    private var pendingExport: File? = null
    private var pendingOpen = ""

    private val openDocument =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> onPicked(uri) }

    private val createDocument =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri -> onExportTarget(uri) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        runtime = PyRuntime(this)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0E1116"))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/out/", WebViewAssetLoader.InternalStoragePathHandler(this, runtime.outDir))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            textZoom = 100
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                openLink(request.url.toString())
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                Log.d("PyStudio-JS", "${m.message()} (${m.sourceId()}:${m.lineNumber()})")
                return true
            }
        }
        web.addJavascriptInterface(JsBridge(runtime, this), "Android")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.PS&&PS.onBack&&PS.onBack())") { result ->
                    if (result != "true") finish()
                }
            }
        })

        runtime.start()
        handleIntent(intent)
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        js("PS.checkPendingOpen")
    }

    override fun onPause() {
        super.onPause()
        js("PS.onPause")
    }

    override fun onDestroy() {
        // The WebView is released with the activity; Python keeps running in the process.
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    // --------------------------------------------------------------- JS helper
    /** Calls a global JS function with JSON-quoted arguments (safe from any thread). */
    fun js(fn: String, vararg args: Any?) {
        val sb = StringBuilder(fn).append('(')
        args.forEachIndexed { i, a ->
            if (i > 0) sb.append(',')
            when (a) {
                null -> sb.append("null")
                is String -> sb.append(JSONObject.quote(a))
                else -> sb.append(a.toString())
            }
        }
        sb.append(')')
        val code = "try{$sb}catch(e){console.error(e&&e.stack||e)}"
        runOnUiThread {
            if (!isDestroyed && ::web.isInitialized) web.evaluateJavascript(code, null)
        }
    }

    // ------------------------------------------------------------ file picking
    fun launchPick(id: String, mode: String) {
        pendingPickId = id
        pendingPickMode = mode
        runOnUiThread {
            try {
                openDocument.launch(arrayOf("*/*"))
            } catch (e: Exception) {
                toast("No file picker available")
                js("PS.onPicked", id, mode, "", "", "error")
            }
        }
    }

    private fun onPicked(uri: Uri?) {
        val id = pendingPickId
        val mode = pendingPickMode
        if (uri == null) {
            js("PS.onPicked", id, mode, "", "", "cancel")
            return
        }
        js("PS.onPickProgress", id)
        Thread {
            try {
                val f = runtime.importUri(uri, mode)
                js("PS.onPicked", id, mode, f.absolutePath, f.name, "ok")
            } catch (e: Exception) {
                js("PS.onPicked", id, mode, "", "", "error:" + (e.message ?: e.toString()))
            }
        }.start()
    }

    // ------------------------------------------------------------------ export
    fun launchExport(file: File, suggestedName: String) {
        pendingExport = file
        runOnUiThread {
            try {
                createDocument.launch(suggestedName.ifBlank { file.name })
            } catch (e: Exception) {
                toast("No file picker available")
            }
        }
    }

    private fun onExportTarget(uri: Uri?) {
        val src = pendingExport
        pendingExport = null
        if (uri == null || src == null) return
        Thread {
            try {
                contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                toast("Saved to your phone")
            } catch (e: Exception) {
                toast("Save failed: ${e.message}")
            }
        }.start()
    }

    // ------------------------------------------------------- "open with" intent
    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        if (intent.action != Intent.ACTION_VIEW) return
        Thread {
            try {
                val f = runtime.importUri(uri, "open")
                pendingOpen = f.name
                js("PS.checkPendingOpen")
            } catch (e: Exception) {
                toast("Cannot open file: ${e.message}")
            }
        }.start()
    }

    fun takePendingOpen(): String {
        val v = pendingOpen
        pendingOpen = ""
        return v
    }

    // ------------------------------------------------------------------ misc
    fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    fun copyToClipboard(text: String) {
        runOnUiThread {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("PyStudio", text))
        }
    }

    fun setBars(color: String, dark: Boolean) {
        runOnUiThread {
            try {
                val c = Color.parseColor(color)
                window.statusBarColor = c
                window.navigationBarColor = c
                web.setBackgroundColor(c)
                val ctl = WindowCompat.getInsetsController(window, web)
                ctl.isAppearanceLightStatusBars = !dark
                ctl.isAppearanceLightNavigationBars = !dark
            } catch (_: Exception) {
            }
        }
    }

    fun openLink(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            toast("No app can open this link")
        }
    }

    /** Last resort when a script cannot be interrupted: restart the whole process. */
    fun restartApp() {
        runOnUiThread {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(launch)
            }
            Runtime.getRuntime().exit(0)
        }
    }

    fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
    } catch (e: Exception) {
        "1.0"
    }
}

package com.pystudio.app

import android.net.Uri
import android.provider.OpenableColumns
import android.view.WindowManager
import android.webkit.JavascriptInterface
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicInteger

/** Receives output from the Python side (called from Python through Chaquopy). */
class PySink(private val host: MainActivity) {
    private class Msg(val text: String?)

    private val inputQueue = LinkedBlockingQueue<Msg>()

    fun onText(channel: String, stream: String, text: String) {
        host.js("PS.onText", channel, stream, text)
    }

    fun onImage(name: String, title: String) {
        host.js("PS.onImage", name, title)
    }

    fun onDone(channel: String, status: String, seconds: Double, errFile: String, errLine: Int, prompt: String) {
        host.js("PS.onDone", channel, status, seconds, errFile, errLine, prompt)
    }

    /** Blocks the Python thread until the user submits a line (or input is cancelled). */
    fun requestInput(channel: String): String? {
        inputQueue.clear()
        host.js("PS.onInputRequest", channel)
        return try {
            inputQueue.take().text
        } catch (e: InterruptedException) {
            null
        }
    }

    fun submitInput(text: String) {
        inputQueue.offer(Msg(text))
    }

    fun cancelInput() {
        inputQueue.offer(Msg(null))
    }
}

/** Owns the embedded Python interpreter and the app workspace. */
class PyRuntime(private val host: MainActivity) {
    val workspace = File(host.filesDir, "workspace")
    val outDir = File(host.cacheDir, "pystudio_out")
    val sink = PySink(host)

    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(null, r, "py-worker", 32L * 1024 * 1024)
    }
    private val pending = AtomicInteger(0)

    private var core: PyObject? = null
    private var readyPayload: String? = null
    private var pageWaiting = false

    init {
        workspace.mkdirs()
        outDir.mkdirs()
    }

    // ---------------------------------------------------------------- startup
    fun start() {
        Thread({
            val payload = try {
                copySamplesOnce()
                if (!Python.isStarted()) {
                    Python.start(AndroidPlatform(host.applicationContext))
                }
                val module = Python.getInstance().getModule("pystudio_core")
                val info = module.callAttr("setup", outDir.absolutePath, sink).toString()
                core = module
                JSONObject(info).put("ok", true).toString()
            } catch (t: Throwable) {
                JSONObject().put("ok", false).put("error", t.toString()).toString()
            }
            synchronized(this) {
                readyPayload = payload
                pushReady()
            }
        }, "py-init").start()
    }

    /** Called by the page when it is loaded. */
    @Synchronized
    fun pageReady() {
        pageWaiting = true
        pushReady()
    }

    private fun pushReady() {
        val p = readyPayload
        if (p != null && pageWaiting) {
            host.js("PS.onReady", p)
        }
    }

    private fun copySamplesOnce() {
        val marker = File(workspace, ".samples_v1")
        if (marker.exists()) return
        copyAssetDir("samples", workspace)
        marker.writeText("1")
    }

    private fun copyAssetDir(assetPath: String, dest: File) {
        val names = host.assets.list(assetPath) ?: return
        if (names.isEmpty()) {
            dest.parentFile?.mkdirs()
            host.assets.open(assetPath).use { input ->
                FileOutputStream(dest).use { input.copyTo(it) }
            }
            return
        }
        dest.mkdirs()
        for (n in names) {
            val target = File(dest, n)
            if (!target.exists()) copyAssetDir("$assetPath/$n", target)
        }
    }

    // ----------------------------------------------------------- python calls
    private fun module(): PyObject = core ?: throw IllegalStateException("Python is still starting")

    private fun submit(channel: String, block: () -> Unit) {
        pending.incrementAndGet()
        setKeepScreenOn(true)
        executor.execute {
            try {
                block()
            } catch (t: Throwable) {
                sink.onText(channel, "stderr", "Internal error: $t\n")
                sink.onDone(channel, "error", 0.0, "", 0, "")
            } finally {
                if (pending.decrementAndGet() == 0) setKeepScreenOn(false)
            }
        }
    }

    private fun setKeepScreenOn(on: Boolean) {
        host.runOnUiThread {
            if (on) host.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else host.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    fun runFile(rel: String, code: String) {
        val f = resolve(rel)
        f.parentFile?.mkdirs()
        f.writeText(code)
        submit("run") { module().callAttr("run_file", f.absolutePath) }
    }

    fun shell(line: String) {
        submit("term") { module().callAttr("shell_exec", line) }
    }

    fun stop() {
        sink.cancelInput()
        Thread {
            try {
                module().callAttr("request_stop")
            } catch (_: Throwable) {
            }
        }.start()
    }

    fun complete(line: String): String = try {
        module().callAttr("shell_complete", line).toString()
    } catch (t: Throwable) {
        "[]"
    }

    fun leaveRepl(): String = try {
        module().callAttr("shell_leave_repl").toString()
    } catch (t: Throwable) {
        ""
    }

    fun pipList(): String = try {
        module().callAttr("pip_list_json").toString()
    } catch (t: Throwable) {
        "[]"
    }

    // ------------------------------------------------------------------ files
    fun resolve(rel: String): File {
        val f = (if (rel.startsWith("/")) File(rel) else File(workspace, rel)).canonicalFile
        val root = workspace.canonicalPath
        require(f.path == root || f.path.startsWith(root + File.separator)) { "Path is outside the workspace" }
        return f
    }

    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) {
            f = File(dir, "$base ($i)$ext")
            i++
        }
        return f
    }

    private fun displayName(uri: Uri): String? {
        try {
            host.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun remoteSize(uri: Uri): Long {
        try {
            host.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
        } catch (_: Exception) {
        }
        return -1
    }

    /**
     * Copies a document picked through Android's file picker into the app workspace.
     * Android's scoped storage gives apps no real path for such files, so the copy's
     * path is what gets inserted into the user's code.
     */
    fun importUri(uri: Uri, mode: String): File {
        val name = (displayName(uri) ?: "file").replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").ifBlank { "file" }
        val dir = if (mode == "path") File(workspace, "inputs") else workspace
        dir.mkdirs()
        var dest = File(dir, name)
        if (mode == "path") {
            if (dest.exists() && dest.length() != remoteSize(uri)) dest = uniqueFile(dir, name)
        } else {
            dest = uniqueFile(dir, name)
        }
        if (!(mode == "path" && dest.exists() && dest.length() == remoteSize(uri))) {
            val input = host.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open file")
            input.use { src -> FileOutputStream(dest).use { src.copyTo(it) } }
        }
        return dest
    }

    fun listFiles(): String {
        val arr = JSONArray()
        fun walk(dir: File, depth: Int) {
            val children = dir.listFiles()
                ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: return
            for (f in children) {
                if (f.name.startsWith(".") || f.name == "__pycache__") continue
                if (arr.length() > 1500) return
                arr.put(
                    JSONObject()
                        .put("path", f.relativeTo(workspace).path)
                        .put("name", f.name)
                        .put("dir", f.isDirectory)
                        .put("size", if (f.isDirectory) 0 else f.length())
                        .put("mtime", f.lastModified())
                        .put("depth", depth)
                )
                if (f.isDirectory && depth < 4) walk(f, depth + 1)
            }
        }
        walk(workspace, 0)
        return arr.toString()
    }
}

/** Methods callable from JavaScript as `Android.xxx()`. */
class JsBridge(private val rt: PyRuntime, private val act: MainActivity) {

    @JavascriptInterface
    fun ready() = rt.pageReady()

    @JavascriptInterface
    fun runFile(rel: String, code: String) = rt.runFile(rel, code)

    @JavascriptInterface
    fun shell(line: String) = rt.shell(line)

    @JavascriptInterface
    fun stop() = rt.stop()

    @JavascriptInterface
    fun submitInput(text: String) = rt.sink.submitInput(text)

    @JavascriptInterface
    fun cancelInput() = rt.sink.cancelInput()

    @JavascriptInterface
    fun complete(line: String): String = rt.complete(line)

    @JavascriptInterface
    fun leaveRepl(): String = rt.leaveRepl()

    @JavascriptInterface
    fun pipList(): String = rt.pipList()

    @JavascriptInterface
    fun listFiles(): String = rt.listFiles()

    @JavascriptInterface
    fun workspacePath(): String = rt.workspace.absolutePath

    @JavascriptInterface
    fun readFile(rel: String): String {
        return try {
            val f = rt.resolve(rel)
            if (!f.isFile) return JSONObject().put("ok", false).put("error", "not a file").toString()
            if (f.length() > 3_000_000) return JSONObject().put("ok", false).put("error", "File is too large to edit (>3 MB)").toString()
            val bytes = f.readBytes()
            if (bytes.any { it.toInt() == 0 }) {
                return JSONObject().put("ok", false).put("error", "Binary files cannot be opened in the editor").toString()
            }
            JSONObject().put("ok", true).put("text", String(bytes, Charsets.UTF_8)).toString()
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("error", t.message ?: t.toString()).toString()
        }
    }

    @JavascriptInterface
    fun writeFile(rel: String, text: String): Boolean {
        return try {
            val f = rt.resolve(rel)
            f.parentFile?.mkdirs()
            f.writeText(text)
            true
        } catch (t: Throwable) {
            false
        }
    }

    @JavascriptInterface
    fun deleteFile(rel: String): Boolean {
        return try {
            val f = rt.resolve(rel)
            if (f == rt.workspace.canonicalFile) false else f.deleteRecursively()
        } catch (t: Throwable) {
            false
        }
    }

    @JavascriptInterface
    fun renameFile(from: String, to: String): Boolean {
        return try {
            val src = rt.resolve(from)
            val dst = rt.resolve(to)
            if (dst.exists()) return false
            dst.parentFile?.mkdirs()
            src.renameTo(dst)
        } catch (t: Throwable) {
            false
        }
    }

    @JavascriptInterface
    fun makeDir(rel: String): Boolean = try {
        rt.resolve(rel).mkdirs()
    } catch (t: Throwable) {
        false
    }

    @JavascriptInterface
    fun fileExists(rel: String): Boolean = try {
        rt.resolve(rel).exists()
    } catch (t: Throwable) {
        false
    }

    /** mode = "path" (copy into workspace/inputs and return its path) or "open" (open in editor). */
    @JavascriptInterface
    fun pickFile(id: String, mode: String) = act.launchPick(id, mode)

    @JavascriptInterface
    fun exportFile(rel: String, suggestedName: String) {
        try {
            act.launchExport(rt.resolve(rel), suggestedName)
        } catch (t: Throwable) {
            act.toast("Export failed: ${t.message}")
        }
    }

    @JavascriptInterface
    fun exportOutput(name: String, suggestedName: String) {
        val f = File(rt.outDir, File(name).name)
        if (f.isFile) act.launchExport(f, suggestedName) else act.toast("Image no longer available")
    }

    @JavascriptInterface
    fun takePendingOpen(): String = act.takePendingOpen()

    @JavascriptInterface
    fun copy(text: String) = act.copyToClipboard(text)

    @JavascriptInterface
    fun toast(msg: String) = act.toast(msg)

    @JavascriptInterface
    fun setBars(color: String, dark: Boolean) = act.setBars(color, dark)

    @JavascriptInterface
    fun openLink(url: String) = act.openLink(url)

    @JavascriptInterface
    fun restartApp() = act.restartApp()

    @JavascriptInterface
    fun versionName(): String = act.versionName()
}

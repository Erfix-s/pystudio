# Welcome to PyStudio - a full Python 3.10 environment on your phone.
# Tap the green Run button. Results appear in the Output tab.
import sys
import platform

print("Hello from PyStudio!")
print("Python", platform.python_version(), "on", platform.machine())
print()

for name in ("numpy", "scipy", "pandas", "matplotlib", "PIL", "cv2", "sklearn", "skimage", "sympy"):
    try:
        mod = __import__(name)
        print("  [ok]  %-11s %s" % (name, getattr(mod, "__version__", "")))
    except Exception as exc:  # pragma: no cover
        print("  [--]  %-11s %s" % (name, exc))

print()
print("Try the examples in the Files drawer (top-left icon).")

# Open ANY photo from your phone and process it.
#
# 1) Put the text cursor between the quotes in cv2.imread("") below
# 2) Tap the  "Pick file"  button that appears above the keyboard
# 3) Choose a photo - its path is inserted for you
# 4) Press Run
import cv2

img = cv2.imread("")

if img is None:
    raise SystemExit("Pick an image first (see the steps at the top of this file).")

print("Image size:", img.shape)
cv2.imshow("Original", img)

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imshow("Grayscale", gray)

edges = cv2.Canny(gray, 80, 180)
cv2.imshow("Edges", edges)

cv2.imwrite("result.png", edges)   # saved in your workspace

# The file picker works for every file type: text, CSV, PDF, audio, ZIP ...
# Place the cursor inside the parentheses of open() and tap "Pick file".
import hashlib
import os

path = ""

if not path:
    raise SystemExit("Put the cursor between the quotes of path = \"\" and tap Pick file.")

size = os.path.getsize(path)
print("File:", os.path.basename(path))
print("Size:", size, "bytes")

with open(path, "rb") as fh:
    data = fh.read()
print("SHA-256:", hashlib.sha256(data).hexdigest())
print("First bytes:", data[:32])

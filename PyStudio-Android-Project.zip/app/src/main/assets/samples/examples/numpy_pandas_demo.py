# NumPy + pandas + scikit-learn quick demo
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

rng = np.random.default_rng(0)
x = rng.uniform(0, 10, 100)
y = 3.5 * x + 2 + rng.normal(0, 1.5, 100)

df = pd.DataFrame({"x": x, "y": y})
print(df.describe().round(2))

model = LinearRegression().fit(df[["x"]], df["y"])
print()
print("slope     :", round(float(model.coef_[0]), 3))
print("intercept :", round(float(model.intercept_), 3))
print("R^2       :", round(model.score(df[["x"]], df["y"]), 4))

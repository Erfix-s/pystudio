# OpenCV demo: draw, filter and show images with cv2.imshow()
import cv2
import numpy as np

# Create a canvas and draw on it
img = np.zeros((360, 480, 3), dtype=np.uint8)
img[:] = (30, 24, 20)
cv2.rectangle(img, (40, 40), (260, 220), (250, 160, 60), 3)
cv2.circle(img, (340, 150), 70, (60, 200, 250), -1)
cv2.line(img, (20, 320), (460, 260), (120, 220, 120), 4)
cv2.putText(img, "PyStudio + OpenCV", (60, 320), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)

cv2.imshow("Original", img)            # shown in the Output tab

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray, 60, 160)
cv2.imshow("Canny edges", edges)

blur = cv2.GaussianBlur(img, (21, 21), 0)
cv2.imshow("Blurred", blur)

cv2.waitKey(0)
print("OpenCV", cv2.__version__)

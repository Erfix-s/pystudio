# Matplotlib demo: plt.show() renders the figure in the Output tab
import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 4 * np.pi, 400)

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
axes[0].plot(x, np.sin(x), label="sin(x)", lw=2)
axes[0].plot(x, np.cos(x), label="cos(x)", lw=2)
axes[0].set_title("Waves")
axes[0].legend()
axes[0].grid(alpha=0.3)

rng = np.random.default_rng(7)
axes[1].scatter(rng.normal(size=300), rng.normal(size=300), c=rng.random(300), cmap="viridis")
axes[1].set_title("Scatter")

plt.tight_layout()
plt.show()

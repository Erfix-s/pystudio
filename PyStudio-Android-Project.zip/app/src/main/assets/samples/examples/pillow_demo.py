# Pillow demo: create an image, apply filters and show it
from PIL import Image, ImageDraw, ImageFilter

img = Image.new("RGB", (480, 300), (24, 28, 40))
draw = ImageDraw.Draw(img)

for i in range(0, 480, 24):
    draw.line([(i, 0), (480 - i, 300)], fill=(60 + i // 3, 120, 255 - i // 3), width=2)

draw.ellipse((170, 80, 310, 220), outline=(255, 214, 10), width=6)
draw.text((150, 130), "PyStudio + Pillow", fill=(255, 255, 255))

img.show("Original")
img.filter(ImageFilter.GaussianBlur(4)).show("Blurred")
img.filter(ImageFilter.CONTOUR).show("Contour")
print(img.size, img.mode)

# input() works: the Output tab shows an input bar while the script waits.
name = input("What is your name? ")
age = int(input("How old are you? "))
print(f"Nice to meet you, {name}! In 10 years you will be {age + 10}.")

total = 0
for i in range(1, 6):
    total += i
    print(i, "->", total)

/* PyStudio - app logic (editor, output, terminal, files, bridge callbacks). */
(function () {
  'use strict';

  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var esc = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); };
  var jparse = function (s, d) { try { return JSON.parse(s); } catch (e) { return d; } };
  var IMG_BASE = 'https://appassets.androidplatform.net/out/';
  var INDENT = '    ';

  var LS = {
    get: function (k, d) { try { var v = localStorage.getItem('ps.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('ps.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };

  // ------------------------------------------------------------------
  // Desktop-preview mock (only used when not running inside the APK)
  // ------------------------------------------------------------------
  function createMock() {
    var fs = jparse(localStorage.getItem('mockfs'), null) || { 'main.py': 'import cv2\nprint("hello")\nimg = cv2.imread("")\n' };
    var save = function () { localStorage.setItem('mockfs', JSON.stringify(fs)); };
    var m = {
      ready: function () { setTimeout(function () { window.PS.onReady(JSON.stringify({ ok: true, python: '3.10 (preview)', workspace: '/mock' })); }, 300); },
      listFiles: function () { return JSON.stringify(Object.keys(fs).sort().map(function (k) { return { path: k, name: k.split('/').pop(), dir: false, size: fs[k].length, mtime: 0, depth: k.split('/').length - 1 }; })); },
      readFile: function (r) { return r in fs ? JSON.stringify({ ok: true, text: fs[r] }) : JSON.stringify({ ok: false, error: 'missing' }); },
      writeFile: function (r, t) { fs[r] = t; save(); return true; },
      deleteFile: function (r) { delete fs[r]; save(); return true; },
      renameFile: function (a, b) { fs[b] = fs[a]; delete fs[a]; save(); return true; },
      makeDir: function () { return true; }, fileExists: function (r) { return r in fs; },
      runFile: function (r, c) { m.writeFile(r, c); setTimeout(function () { window.PS.onText('run', 'stdout', '[preview] would run ' + r + '\n'); window.PS.onDone('run', 'ok', 0.01, '', 0, ''); }, 200); },
      shell: function (l) { setTimeout(function () { window.PS.onText('term', 'stdout', '[preview] ' + l + '\n'); window.PS.onDone('term', 'ok', 0.01, '', 0, 'pystudio:~ $ '); }, 100); },
      stop: function () { }, submitInput: function () { }, cancelInput: function () { }, complete: function () { return '[]'; },
      leaveRepl: function () { return 'pystudio:~ $ '; },
      pipList: function () { return JSON.stringify([{ name: 'numpy', version: '1.23.3', source: 'bundled' }, { name: 'rich', version: '13.0', source: 'installed' }]); },
      workspacePath: function () { return '/mock'; },
      pickFile: function (id, mode) { setTimeout(function () { window.PS.onPicked(id, mode, '/mock/inputs/photo.jpg', 'photo.jpg', 'ok'); }, 100); },
      exportFile: function () { }, exportOutput: function () { }, takePendingOpen: function () { return ''; },
      copy: function () { }, toast: function () { }, setBars: function () { }, openLink: function () { }, restartApp: function () { },
      versionName: function () { return '1.0.0-preview'; }
    };
    return m;
  }
  var A = window.Android || createMock();

  // ------------------------------------------------------------------
  // State
  // ------------------------------------------------------------------
  var S = {
    file: LS.get('file', 'main.py'),
    dirty: false, ready: false, view: 'editor',
    busy: null, stopping: false, awaiting: null,
    prompt: 'pystudio:~ $ ', repl: false,
    errLine: 0, errTarget: null,
    workspace: '', python: '',
    cfg: Object.assign({ theme: 'dark', fs: 14, autoclose: true, autosave: true, clearOnRun: true }, LS.get('cfg', {})),
    hist: LS.get('hist', []), histPos: -1, histDraft: '',
    collapsed: LS.get('collapsed', [])
  };

  var ta = $('#ta'), hl = $('#hl'), gutter = $('#gutter'), scroller = $('#scroller');
  var curLine = $('#cur-line'), errLine = $('#err-line'), findHl = $('#find-hl');
  var chip = $('#call-chip');
  var outCon = new window.PSConsole($('#out'));
  var termCon = new window.PSConsole($('#term'));
  var termInput = $('#term-input'), outInput = $('#out-input');
  var PAD = 10, PADX = 12, LH = 21, CW = 8.4;

  // ------------------------------------------------------------------
  // Helpers: toast, dialogs, sheets
  // ------------------------------------------------------------------
  var toastTimer = null;
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, 2200);
  }

  var dlgResolve = null;
  function closeDialog(val) {
    $('#dialog').hidden = true;
    var r = dlgResolve; dlgResolve = null;
    if (r) r(val);
  }
  /** Promise-based dialog. Returns string (input / choice id), true (confirm) or null (cancel). */
  function ask(o) {
    return new Promise(function (resolve) {
      if (dlgResolve) closeDialog(null);
      dlgResolve = resolve;
      $('#dialog-title').textContent = o.title || '';
      $('#dialog-msg').textContent = o.message || '';
      var inp = $('#dialog-input');
      inp.hidden = o.value == null;
      inp.value = o.value == null ? '' : o.value;
      var old = $('#dialog-choices');
      if (old) old.remove();
      var okBtn = $('#dialog-ok');
      okBtn.textContent = o.ok || 'OK';
      okBtn.className = o.danger ? 'danger' : 'primary';
      okBtn.hidden = !!o.choices;
      $('#dialog-cancel').textContent = o.choices ? 'Close' : 'Cancel';
      if (o.choices) {
        var box = document.createElement('div');
        box.id = 'dialog-choices';
        box.style.cssText = 'display:flex;flex-direction:column;gap:6px;margin-bottom:12px';
        o.choices.forEach(function (c) {
          var b = document.createElement('button');
          b.type = 'button';
          b.textContent = c.label;
          b.style.cssText = 'height:44px;border-radius:12px;background:var(--bg3);font-weight:600;text-align:left;padding:0 14px;' + (c.danger ? 'color:var(--red)' : '');
          b.addEventListener('click', function () { closeDialog(c.id); });
          box.appendChild(b);
        });
        $('#dialog-card').insertBefore(box, $('.dlg-actions'));
      }
      $('#dialog').hidden = false;
      if (o.value != null) setTimeout(function () { inp.focus(); inp.select(); }, 60);
    });
  }
  $('#dialog-card').addEventListener('submit', function (e) {
    e.preventDefault();
    var inp = $('#dialog-input');
    closeDialog(inp.hidden ? true : inp.value);
  });
  $('#dialog-cancel').addEventListener('click', function () { closeDialog(null); });
  $('#dialog').addEventListener('click', function (e) { if (e.target.id === 'dialog') closeDialog(null); });

  function openSheet(id) {
    closeSheets();
    var s = $(id);
    s.classList.add('open');
    s.setAttribute('aria-hidden', 'false');
    $('#scrim').hidden = false;
  }
  function closeSheets() {
    var any = false;
    $$('.sheet.open').forEach(function (s) { s.classList.remove('open'); s.setAttribute('aria-hidden', 'true'); any = true; });
    $('#scrim').hidden = true;
    return any;
  }
  $('#scrim').addEventListener('click', closeSheets);
  $$('[data-close]').forEach(function (b) { b.addEventListener('click', closeSheets); });

  // ------------------------------------------------------------------
  // Settings / theme
  // ------------------------------------------------------------------
  function measure() {
    var s = document.createElement('span');
    s.className = 'mono';
    s.style.cssText = 'position:absolute;visibility:hidden;white-space:pre;left:-9999px';
    s.textContent = new Array(41).join('M');
    document.body.appendChild(s);
    CW = s.getBoundingClientRect().width / 40;
    s.remove();
  }
  function applyCfg() {
    var c = S.cfg, root = document.documentElement;
    root.dataset.theme = c.theme;
    LH = Math.round(c.fs * 1.5);
    root.style.setProperty('--fs', c.fs + 'px');
    root.style.setProperty('--lh', LH + 'px');
    measure();
    var bar = getComputedStyle(root).getPropertyValue('--bar').trim() || '#0d1117';
    try { A.setBars(bar, c.theme === 'dark'); } catch (e) { /* ignore */ }
    $$('#set-theme button').forEach(function (b) { b.classList.toggle('on', b.dataset.v === c.theme); });
    $('#fs-val').textContent = c.fs;
    $('#set-autoclose').checked = c.autoclose;
    $('#set-autosave').checked = c.autosave;
    $('#set-clear').checked = c.clearOnRun;
    positionOverlays();
  }
  function saveCfg() { LS.set('cfg', S.cfg); applyCfg(); }
  $$('#set-theme button').forEach(function (b) { b.addEventListener('click', function () { S.cfg.theme = b.dataset.v; saveCfg(); }); });
  $('#fs-minus').addEventListener('click', function () { S.cfg.fs = Math.max(10, S.cfg.fs - 1); saveCfg(); });
  $('#fs-plus').addEventListener('click', function () { S.cfg.fs = Math.min(24, S.cfg.fs + 1); saveCfg(); });
  $('#set-autoclose').addEventListener('change', function (e) { S.cfg.autoclose = e.target.checked; saveCfg(); });
  $('#set-autosave').addEventListener('change', function (e) { S.cfg.autosave = e.target.checked; saveCfg(); });
  $('#set-clear').addEventListener('change', function (e) { S.cfg.clearOnRun = e.target.checked; saveCfg(); });

  // ------------------------------------------------------------------
  // Editor core
  // ------------------------------------------------------------------
  var lineCount = 0, renderQueued = false, caretQueued = false;

  function render() {
    renderQueued = false;
    var v = ta.value;
    hl.innerHTML = window.PSCode.highlight(v) + '\n ';
    var n = 1;
    for (var i = v.indexOf('\n'); i !== -1; i = v.indexOf('\n', i + 1)) n++;
    if (n !== lineCount) {
      lineCount = n;
      var s = '';
      for (var k = 1; k <= n; k++) s += k + (k < n ? '\n' : '');
      gutter.textContent = s;
    }
  }
  function scheduleRender() { if (!renderQueued) { renderQueued = true; requestAnimationFrame(render); } }

  function lineColOf(v, pos) {
    var line = 0, last = -1;
    for (var i = v.indexOf('\n'); i !== -1 && i < pos; i = v.indexOf('\n', i + 1)) { line++; last = i; }
    return { line: line, col: pos - last - 1 };
  }

  function positionOverlays() {
    var v = ta.value, p = ta.selectionStart;
    var lc = lineColOf(v, p);
    curLine.style.top = (PAD + lc.line * LH) + 'px';
    if (S.errLine > 0) {
      errLine.style.display = 'block';
      errLine.style.top = (PAD + (S.errLine - 1) * LH) + 'px';
    } else errLine.style.display = 'none';
  }

  function onCaret() {
    caretQueued = false;
    var v = ta.value, p = ta.selectionStart, collapsed = p === ta.selectionEnd;
    curLine.style.display = collapsed ? 'block' : 'none';
    positionOverlays();
    updateChip(v, p, collapsed);
  }
  function scheduleCaret() { if (!caretQueued) { caretQueued = true; requestAnimationFrame(onCaret); } }

  var PICK_SVG = '<svg viewBox="0 0 24 24"><path d="M3 6.5A2.5 2.5 0 0 1 5.5 4h4l2 2.5h7A2.5 2.5 0 0 1 21 9v8.5a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/></svg>';
  function updateChip(v, p, collapsed) {
    if (!collapsed) { chip.hidden = true; return; }
    if (document.activeElement !== ta) return;   // keep the chip while it is being tapped
    var r = window.PSCode.scan(v, p);
    if (r.call) {
      var key = r.call.name;
      if (chip.hidden || chip.dataset.n !== key) {
        chip.innerHTML = PICK_SVG + '<span>Pick file for</span><code>' + esc(key) + '( )</code><span class="go">&#8250;</span>';
        chip.dataset.n = key;
      }
      chip.hidden = false;
    } else {
      chip.hidden = true;
    }
  }

  function revealCaret() {
    var p = ta.selectionStart, lc = lineColOf(ta.value, p);
    var y = PAD + lc.line * LH;
    var st = scroller.scrollTop, ch = scroller.clientHeight;
    if (y < st + 4) scroller.scrollTop = Math.max(0, y - 8);
    else if (y + LH > st + ch - 10) scroller.scrollTop = y + LH - ch + 14;
    var gw = gutter.offsetWidth;
    var x = gw + PADX + lc.col * CW;
    var sl = scroller.scrollLeft, cw = scroller.clientWidth;
    if (x > sl + cw - 24) scroller.scrollLeft = x - cw + 70;
    else if (x < sl + gw + 6) scroller.scrollLeft = Math.max(0, x - gw - 60);
  }

  function replaceRange(start, end, text, caretStart, caretEnd) {
    try { ta.focus({ preventScroll: true }); } catch (e) { ta.focus(); }
    ta.setSelectionRange(start, end);
    var ok = false;
    if (text !== '') { try { ok = document.execCommand('insertText', false, text); } catch (e) { ok = false; } }
    if (!ok) {
      ta.setRangeText(text, start, end, 'end');
      ta.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (caretStart != null) ta.setSelectionRange(caretStart, caretEnd == null ? caretStart : caretEnd);
    scheduleCaret();
    requestAnimationFrame(revealCaret);
  }

  function onInput() {
    S.dirty = true;
    if (S.errLine) { S.errLine = 0; positionOverlays(); }
    clearFind();
    updateTitle();
    scheduleRender();
    scheduleCaret();
    requestAnimationFrame(revealCaret);
    scheduleAutosave();
  }

  var autosaveTimer = null;
  function scheduleAutosave() {
    if (!S.cfg.autosave) return;
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(function () { saveFile(true); }, 700);
  }

  function updateTitle() {
    $('#file-name').textContent = S.file;
    $('#dirty').hidden = !S.dirty;
  }

  // ---- smart typing --------------------------------------------------
  var OPEN = { '(': ')', '[': ']', '{': '}' };
  var PAIRS = { '(': ')', '[': ']', '{': '}', '"': '"', "'": "'" };

  function smartEnter() {
    var v = ta.value, p = ta.selectionStart, e = ta.selectionEnd;
    var ls = v.lastIndexOf('\n', p - 1) + 1;
    var before = v.slice(ls, p);
    var indent = /^[ \t]*/.exec(before)[0];
    var trimmed = before.replace(/\s+$/, '');
    var extra = '';
    if (/:\s*(#.*)?$/.test(trimmed) && !/^\s*#/.test(trimmed)) extra = INDENT;
    else if (/^\s*(return|pass|break|continue|raise)\b/.test(before) && indent.length >= 4) indent = indent.slice(0, indent.length - 4);
    var prev = v.charAt(p - 1), next = v.charAt(p);
    if (OPEN[prev] && OPEN[prev] === next && p === e) {
      var mid = '\n' + indent + INDENT;
      replaceRange(p, e, mid + '\n' + indent, p + mid.length);
    } else {
      replaceRange(p, e, '\n' + indent + extra);
    }
  }

  function handleChar(ch) {
    var v = ta.value, p = ta.selectionStart, e = ta.selectionEnd;
    if (')]}"\''.indexOf(ch) !== -1 && p === e && v.charAt(p) === ch) {
      ta.setSelectionRange(p + 1, p + 1);
      scheduleCaret();
      return true;
    }
    if (OPEN[ch]) {
      if (p !== e) {
        replaceRange(p, e, ch + v.slice(p, e) + OPEN[ch], p + 1, e + 1);
        return true;
      }
      var nx = v.charAt(p);
      if (!nx || /[\s)\]}:,;]/.test(nx)) {
        replaceRange(p, e, ch + OPEN[ch], p + 1);
        return true;
      }
      return false;
    }
    if (ch === '"' || ch === "'") {
      if (p !== e) {
        replaceRange(p, e, ch + v.slice(p, e) + ch, p + 1, e + 1);
        return true;
      }
      var pv = v.charAt(p - 1), nx2 = v.charAt(p);
      if (/[A-Za-z0-9_]/.test(pv) && !/^[rRbBuUfF]$/.test(pv)) return false;
      if (v.slice(p - 2, p) === ch + ch) return false;           // typing a triple quote
      if (nx2 && !/[\s)\]}:,;]/.test(nx2)) return false;
      replaceRange(p, e, ch + ch, p + 1);
      return true;
    }
    return false;
  }

  function indentLines(outdent) {
    var v = ta.value, s = ta.selectionStart, e = ta.selectionEnd;
    var ls = v.lastIndexOf('\n', s - 1) + 1;
    var end = e;
    if (e > s && v.charAt(e - 1) === '\n') end = e - 1;
    var le = v.indexOf('\n', end);
    if (le < 0) le = v.length;
    var lines = v.slice(ls, le).split('\n').map(function (l) {
      return outdent ? l.replace(/^( {1,4}|\t)/, '') : (l.length ? INDENT + l : l);
    });
    var nl = lines.join('\n');
    replaceRange(ls, le, nl, ls, ls + nl.length);
  }

  function toggleComment() {
    var v = ta.value, s = ta.selectionStart, e = ta.selectionEnd;
    var ls = v.lastIndexOf('\n', s - 1) + 1;
    var end = (e > s && v.charAt(e - 1) === '\n') ? e - 1 : e;
    var le = v.indexOf('\n', end);
    if (le < 0) le = v.length;
    var lines = v.slice(ls, le).split('\n');
    var allCommented = lines.every(function (l) { return !l.trim() || /^\s*#/.test(l); });
    var minIndent = lines.reduce(function (m, l) { return l.trim() ? Math.min(m, /^[ \t]*/.exec(l)[0].length) : m; }, 1e9);
    if (minIndent === 1e9) minIndent = 0;
    var out = lines.map(function (l) {
      if (!l.trim()) return l;
      if (allCommented) return l.replace(/^(\s*)# ?/, '$1');
      return l.slice(0, minIndent) + '# ' + l.slice(minIndent);
    }).join('\n');
    replaceRange(ls, le, out, ls, ls + out.length);
  }

  function insertText(t) {
    if (t.length === 1 && S.cfg.autoclose && handleChar(t)) return;
    var p = ta.selectionStart, e = ta.selectionEnd;
    replaceRange(p, e, t);
  }

  ta.addEventListener('beforeinput', function (e) {
    if (e.isComposing) return;
    var t = e.inputType;
    if (t === 'insertLineBreak' || t === 'insertParagraph') { e.preventDefault(); smartEnter(); return; }
    if (!S.cfg.autoclose) return;
    if (t === 'insertText' && e.data && e.data.length === 1) {
      if (handleChar(e.data)) e.preventDefault();
    } else if (t === 'deleteContentBackward' && ta.selectionStart === ta.selectionEnd) {
      var p = ta.selectionStart, v = ta.value;
      if (p > 0 && PAIRS[v.charAt(p - 1)] === v.charAt(p)) {
        e.preventDefault();
        replaceRange(p - 1, p + 1, '', p - 1);
      }
    }
  });
  ta.addEventListener('input', onInput);
  ta.addEventListener('keydown', function (e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      if (ta.selectionStart !== ta.selectionEnd || e.shiftKey) indentLines(e.shiftKey); else insertText(INDENT);
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault(); runOrStop();
    } else if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
      e.preventDefault(); saveFile(false);
    } else if ((e.ctrlKey || e.metaKey) && e.key === '/') {
      e.preventDefault(); toggleComment();
    }
  });
  ['keyup', 'click', 'touchend', 'select', 'focus'].forEach(function (ev) { ta.addEventListener(ev, scheduleCaret); });
  document.addEventListener('selectionchange', function () { if (document.activeElement === ta) scheduleCaret(); });
  ta.addEventListener('blur', function () { setTimeout(function () { if (document.activeElement !== ta && !chipTouched) chip.hidden = true; }, 250); });

  var chipTouched = false;
  ['mousedown', 'touchstart'].forEach(function (ev) {
    chip.addEventListener(ev, function (e) { chipTouched = true; setTimeout(function () { chipTouched = false; }, 600); if (ev === 'mousedown') e.preventDefault(); }, { passive: ev === 'touchstart' });
  });
  $('#symbols').addEventListener('mousedown', function (e) { e.preventDefault(); });

  $('#symbols').addEventListener('click', function (e) {
    var b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.ins != null) { insertText(b.dataset.ins); return; }
    var act = b.dataset.act;
    if (act === 'tab') {
      if (ta.selectionStart !== ta.selectionEnd) indentLines(false); else insertText(INDENT);
    } else if (act === 'outdent') indentLines(true);
    else if (act === 'comment') toggleComment();
    else if (act === 'undo') { ta.focus(); document.execCommand('undo'); onInput(); }
    else if (act === 'redo') { ta.focus(); document.execCommand('redo'); onInput(); }
    else if (act === 'pick') pickAndInsert();
  });

  // ---- file picker (insert path between the parentheses) --------------
  var pickSeq = 0, pickWaiters = {};
  function requestPick(mode) {
    return new Promise(function (resolve) {
      var id = String(++pickSeq);
      pickWaiters[id] = resolve;
      A.pickFile(id, mode);
    });
  }

  function pickAndInsert() {
    var s = ta.selectionStart, e = ta.selectionEnd;
    requestPick('path').then(function (r) {
      if (r.status !== 'ok') {
        if (r.status !== 'cancel') toast('Could not import file: ' + String(r.status).replace(/^error:?\s*/, ''));
        return;
      }
      showView('editor');
      var plan = window.PSCode.planPathInsert(ta.value, s, e, r.path);
      replaceRange(plan.start, plan.end, plan.text, plan.caret);
      toast('Path inserted: ' + r.name);
    });
  }
  chip.addEventListener('click', pickAndInsert);

  // ---- find & replace --------------------------------------------------
  var find = { q: '', idx: -1 };
  function matches() {
    var q = $('#find-input').value, v = ta.value, out = [];
    if (!q) return out;
    var lv = v.toLowerCase(), lq = q.toLowerCase();
    for (var i = lv.indexOf(lq); i !== -1 && out.length < 5000; i = lv.indexOf(lq, i + Math.max(1, lq.length))) out.push(i);
    return out;
  }
  function clearFind() { findHl.style.display = 'none'; }
  function showMatch(list, k) {
    var q = $('#find-input').value;
    if (!list.length) { $('#find-count').textContent = '0/0'; clearFind(); return; }
    k = ((k % list.length) + list.length) % list.length;
    find.idx = k;
    var pos = list[k], lc = lineColOf(ta.value, pos);
    $('#find-count').textContent = (k + 1) + '/' + list.length;
    findHl.style.display = 'block';
    findHl.style.top = (PAD + lc.line * LH) + 'px';
    findHl.style.left = (PADX + lc.col * CW) + 'px';
    findHl.style.width = (q.length * CW) + 'px';
    ta.setSelectionRange(pos, pos + q.length);
    var y = PAD + lc.line * LH;
    scroller.scrollTop = Math.max(0, y - scroller.clientHeight / 3);
    var x = gutter.offsetWidth + PADX + lc.col * CW;
    if (x > scroller.scrollLeft + scroller.clientWidth - 30) scroller.scrollLeft = x - scroller.clientWidth / 2;
  }
  function findStep(dir) {
    var list = matches();
    if (!list.length) { showMatch(list, 0); return; }
    var cur = ta.selectionStart, k;
    if (dir > 0) { k = list.findIndex(function (p) { return p >= cur + (find.idx >= 0 && ta.selectionEnd > ta.selectionStart ? 1 : 0); }); if (k < 0) k = 0; }
    else { k = -1; for (var i = list.length - 1; i >= 0; i--) { if (list[i] < cur) { k = i; break; } } if (k < 0) k = list.length - 1; }
    showMatch(list, k);
  }
  $('#find-input').addEventListener('input', function () { find.idx = -1; var l = matches(); showMatch(l, 0); });
  $('#find-input').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); findStep(1); } });
  $('#find-next').addEventListener('click', function () { findStep(1); });
  $('#find-prev').addEventListener('click', function () { findStep(-1); });
  $('#find-close').addEventListener('click', function () { $('#findbar').hidden = true; clearFind(); });
  $('#replace-one').addEventListener('click', function () {
    var q = $('#find-input').value;
    if (!q) return;
    var s = ta.selectionStart, e = ta.selectionEnd;
    if (ta.value.slice(s, e).toLowerCase() === q.toLowerCase()) replaceRange(s, e, $('#replace-input').value, s + $('#replace-input').value.length);
    findStep(1);
  });
  $('#replace-all').addEventListener('click', function () {
    var q = $('#find-input').value;
    if (!q) return;
    var list = matches();
    if (!list.length) return;
    var rep = $('#replace-input').value, v = ta.value, out = '', last = 0;
    list.forEach(function (p) { out += v.slice(last, p) + rep; last = p + q.length; });
    out += v.slice(last);
    replaceRange(0, v.length, out, 0);
    toast(list.length + ' replaced');
    $('#find-count').textContent = '0/0';
  });
  function openFind() {
    $('#findbar').hidden = false;
    var sel = ta.value.slice(ta.selectionStart, ta.selectionEnd);
    if (sel && sel.indexOf('\n') === -1) $('#find-input').value = sel;
    setTimeout(function () { $('#find-input').focus(); $('#find-input').select(); }, 50);
  }

  // ------------------------------------------------------------------
  // Files
  // ------------------------------------------------------------------
  function setText(t) {
    ta.value = t;
    render();
    scroller.scrollTop = 0; scroller.scrollLeft = 0;
    ta.setSelectionRange(0, 0);
    clearFind();
    onCaret();
  }

  function saveFile(silent) {
    clearTimeout(autosaveTimer);
    var ok = A.writeFile(S.file, ta.value);
    if (ok) { S.dirty = false; updateTitle(); if (!silent) toast('Saved ' + S.file); }
    else if (!silent) toast('Could not save file');
    return ok;
  }

  function openFile(rel) {
    if (S.dirty) saveFile(true);
    var r = jparse(A.readFile(rel), { ok: false, error: 'Cannot read file' });
    if (!r.ok) { toast(r.error || 'Cannot open file'); return false; }
    S.file = rel; LS.set('file', rel);
    setText(r.text);
    S.dirty = false; S.errLine = 0;
    positionOverlays(); updateTitle();
    closeSheets();
    showView('editor');
    return true;
  }

  function relFromAbs(p) {
    var ws = S.workspace;
    if (ws && p.indexOf(ws + '/') === 0) return p.slice(ws.length + 1);
    return p;
  }

  function fmtSize(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(1) + ' MB';
  }

  function iconFor(f, collapsed) {
    if (f.dir) return collapsed ? '\uD83D\uDCC1' : '\uD83D\uDCC2';
    var n = f.name.toLowerCase();
    if (/\.py$/.test(n)) return '\uD83D\uDC0D';
    if (/\.(png|jpe?g|gif|bmp|webp)$/.test(n)) return '\uD83D\uDDBC\uFE0F';
    return '\uD83D\uDCC4';
  }

  function refreshFiles() {
    var list = jparse(A.listFiles(), []);
    var html = '', hidden = null;
    list.forEach(function (f) {
      if (hidden && f.path.indexOf(hidden + '/') === 0) return;
      hidden = null;
      var coll = f.dir && S.collapsed.indexOf(f.path) !== -1;
      if (coll) hidden = f.path;
      html += '<div class="frow-item' + (f.path === S.file ? ' sel' : '') + '">' +
        '<button class="fi-main" data-path="' + esc(f.path) + '" data-dir="' + (f.dir ? 1 : 0) + '">' +
        '<span style="width:' + (f.depth * 14) + 'px;flex:none"></span>' +
        '<span class="fi-ico">' + iconFor(f, coll) + '</span><span class="fi-name">' + esc(f.name) + '</span></button>' +
        (f.dir ? '' : '<span class="fi-meta">' + fmtSize(f.size) + '</span>') +
        '<button class="fi-more" data-more="' + esc(f.path) + '" data-dir="' + (f.dir ? 1 : 0) + '" aria-label="More">&#8942;</button></div>';
    });
    $('#file-list').innerHTML = html || '<p class="hint">No files yet. Tap the new-file icon above.</p>';
    $('#ws-path').textContent = S.workspace || '';
  }

  $('#file-list').addEventListener('click', function (e) {
    var more = e.target.closest('[data-more]');
    if (more) { fileMenu(more.dataset.more, more.dataset.dir === '1'); return; }
    var b = e.target.closest('.fi-main');
    if (!b) return;
    var path = b.dataset.path;
    if (b.dataset.dir === '1') {
      var i = S.collapsed.indexOf(path);
      if (i >= 0) S.collapsed.splice(i, 1); else S.collapsed.push(path);
      LS.set('collapsed', S.collapsed);
      refreshFiles();
    } else openFile(path);
  });

  function baseName(p) { return p.split('/').pop(); }
  function dirName(p) { var i = p.lastIndexOf('/'); return i < 0 ? '' : p.slice(0, i); }

  function fileMenu(path, isDir) {
    var choices = [];
    if (!isDir) choices.push({ id: 'open', label: 'Open' });
    if (isDir) choices.push({ id: 'newhere', label: 'New file in this folder' });
    choices.push({ id: 'rename', label: 'Rename' });
    if (!isDir) {
      choices.push({ id: 'dup', label: 'Duplicate' });
      choices.push({ id: 'export', label: 'Save copy to phone' });
    }
    choices.push({ id: 'delete', label: 'Delete', danger: true });
    ask({ title: baseName(path), message: path, choices: choices }).then(function (id) {
      if (!id) return;
      if (id === 'open') openFile(path);
      else if (id === 'newhere') newFile(path);
      else if (id === 'rename') {
        ask({ title: 'Rename', value: baseName(path), ok: 'Rename' }).then(function (nm) {
          if (!nm || !nm.trim()) return;
          var dst = (dirName(path) ? dirName(path) + '/' : '') + nm.trim();
          if (A.fileExists(dst)) { toast('That name already exists'); return; }
          if (A.renameFile(path, dst)) {
            if (S.file === path) { S.file = dst; LS.set('file', dst); updateTitle(); }
            refreshFiles();
          } else toast('Rename failed');
        });
      } else if (id === 'dup') {
        var r = jparse(A.readFile(path), { ok: false });
        if (!r.ok) { toast(r.error || 'Cannot read file'); return; }
        var dot = path.lastIndexOf('.');
        var copy = (dot > 0 ? path.slice(0, dot) : path) + '_copy' + (dot > 0 ? path.slice(dot) : '');
        A.writeFile(copy, r.text);
        refreshFiles();
        toast('Created ' + baseName(copy));
      } else if (id === 'export') {
        A.exportFile(path, baseName(path));
      } else if (id === 'delete') {
        ask({ title: 'Delete ' + baseName(path) + '?', message: isDir ? 'The folder and everything inside it will be removed.' : 'This cannot be undone.', ok: 'Delete', danger: true }).then(function (yes) {
          if (!yes) return;
          if (A.deleteFile(path)) {
            if (S.file === path || S.file.indexOf(path + '/') === 0) {
              S.dirty = false;
              var fallback = 'main.py';
              if (!A.fileExists(fallback)) A.writeFile(fallback, '# New file\n');
              openFile(fallback);
              openSheet('#sheet-files');
            }
            refreshFiles();
          } else toast('Delete failed');
        });
      }
    });
  }

  function newFile(folder) {
    var prefix = folder ? folder + '/' : '';
    ask({ title: 'New file', message: folder ? 'In ' + folder : '', value: 'untitled.py', ok: 'Create' }).then(function (nm) {
      if (!nm || !nm.trim()) return;
      nm = nm.trim();
      if (!/\.[A-Za-z0-9]+$/.test(nm)) nm += '.py';
      var rel = prefix + nm;
      if (A.fileExists(rel)) { toast('That file already exists'); return; }
      A.writeFile(rel, nm.slice(-3) === '.py' ? '# ' + nm + '\n' : '');
      openFile(rel);
      refreshFiles();
    });
  }
  function newFolder() {
    ask({ title: 'New folder', value: 'folder', ok: 'Create' }).then(function (nm) {
      if (!nm || !nm.trim()) return;
      if (A.makeDir(nm.trim())) refreshFiles(); else toast('Could not create folder');
    });
  }
  function openFromPhone() {
    requestPick('open').then(function (r) {
      if (r.status === 'ok') {
        if (openFile(r.name)) { toast('Opened ' + r.name); refreshFiles(); }
      } else if (r.status !== 'cancel') toast('Could not open: ' + String(r.status).replace(/^error:?\s*/, ''));
    });
  }

  $('#btn-files').addEventListener('click', function () { refreshFiles(); openSheet('#sheet-files'); });
  $('#file-chip').addEventListener('click', function () { refreshFiles(); openSheet('#sheet-files'); });
  $('#f-newfile').addEventListener('click', function () { newFile(''); });
  $('#f-newdir').addEventListener('click', newFolder);
  $('#f-open').addEventListener('click', openFromPhone);

  // ------------------------------------------------------------------
  // Menu / libraries / about
  // ------------------------------------------------------------------
  $('#btn-menu').addEventListener('click', function () { openSheet('#sheet-menu'); });
  $$('#sheet-menu .mi').forEach(function (b) {
    b.addEventListener('click', function () {
      var m = b.dataset.m;
      closeSheets();
      if (m === 'save') saveFile(false);
      else if (m === 'newfile') newFile('');
      else if (m === 'open') openFromPhone();
      else if (m === 'export') { saveFile(true); A.exportFile(S.file, baseName(S.file)); }
      else if (m === 'find') { showView('editor'); openFind(); }
      else if (m === 'libs') { refreshLibs(); openSheet('#sheet-libs'); }
      else if (m === 'settings') openSheet('#sheet-settings');
      else if (m === 'about') { renderAbout(); openSheet('#sheet-about'); }
    });
  });

  function refreshLibs() {
    var list = jparse(A.pipList(), []);
    $('#lib-list').innerHTML = list.map(function (p) {
      return '<div class="lib-row"><span class="nm">' + esc(p.name) + '</span><span class="vr">' + esc(p.version === '?' ? '' : p.version) + '</span>' +
        '<span class="pill ' + (p.source === 'installed' ? 'inst' : '') + '">' + esc(p.source) + '</span></div>';
    }).join('') || '<p class="hint">No package information available yet.</p>';
  }
  $('#lib-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var name = $('#lib-input').value.trim();
    if (!name) return;
    $('#lib-input').value = '';
    closeSheets();
    showView('term');
    termExec('pip install ' + name);
  });

  function renderAbout() {
    var v = '';
    try { v = A.versionName(); } catch (e) { v = ''; }
    $('#about-body').innerHTML =
      '<p><b>PyStudio ' + esc(v) + '</b><br><span class="muted">Python ' + esc(S.python || '3.10') + ' &middot; runs 100% on your phone</span></p>' +
      '<h4>File picker</h4><p>Put the cursor inside a call such as <code>cv2.imread( )</code> and tap <b>Pick file</b>. Any file type works. ' +
      'Android\u2019s privacy rules give apps no direct path to files elsewhere on the phone, so PyStudio copies the file into its workspace (<code>inputs/</code>) and inserts that path.</p>' +
      '<h4>Libraries</h4><p>NumPy, SciPy, pandas, Matplotlib, Pillow, OpenCV, scikit-learn, scikit-image, SymPy, requests and more are bundled. ' +
      '<code>pip install</code> works for pure-Python packages. Native packages must be added to <code>app/build.gradle.kts</code> and rebuilt \u2013 Android cannot load native code downloaded at runtime.</p>' +
      '<h4>Windows &amp; graphics</h4><p>There is no desktop window system: <code>plt.show()</code>, <code>cv2.imshow()</code> and <code>Image.show()</code> are rendered as images in the Output tab. Camera/video-capture APIs and Tkinter are unavailable.</p>' +
      '<h4>Stopping code</h4><p>Stop raises <code>KeyboardInterrupt</code>. Code stuck inside a long native call may need <b>Force restart</b>.</p>' +
      '<h4>Updates</h4><p>New builds are signed with the same key, so they install over the old version and keep your files.</p>';
  }

  // ------------------------------------------------------------------
  // Views / tabs
  // ------------------------------------------------------------------
  function showView(name) {
    S.view = name;
    $$('.view').forEach(function (v) { v.classList.toggle('active', v.id === 'view-' + name); });
    $$('.tab').forEach(function (t) { t.classList.toggle('active', t.dataset.view === name); });
    if (name === 'output') { $('#badge-out').hidden = true; outCon.scrollDown(); }
    if (name === 'term') { $('#badge-term').hidden = true; termCon.scrollDown(); setTimeout(function () { termInput.focus(); }, 80); }
    if (name === 'editor') { setTimeout(function () { positionOverlays(); }, 0); }
  }
  $$('.tab').forEach(function (t) { t.addEventListener('click', function () { showView(t.dataset.view); }); });

  // keyboard open/close detection (hides the bottom tabs while typing)
  var maxH = window.innerHeight;
  window.addEventListener('resize', function () {
    maxH = Math.max(maxH, window.innerHeight);
    var kb = maxH - window.innerHeight > 140;
    document.body.classList.toggle('kb', kb);
    if (document.activeElement === ta) setTimeout(revealCaret, 60);
    if (S.view === 'output') outCon.scrollDown();
    if (S.view === 'term') termCon.scrollDown();
  });
  window.addEventListener('orientationchange', function () { setTimeout(function () { maxH = window.innerHeight; }, 400); });

  // ------------------------------------------------------------------
  // Run / stop
  // ------------------------------------------------------------------
  var forceTimer = null;
  function setStatus(kind, text) {
    $('#status').className = 'status ' + kind;
    $('#status-text').textContent = text;
  }
  function updateRunBtn() {
    var b = $('#btn-run');
    b.classList.toggle('stop', !!S.busy);
    $('#run-label').textContent = S.busy ? 'Stop' : 'Run';
  }
  function setBusy(ch) {
    S.busy = ch;
    S.stopping = false;
    updateRunBtn();
    if (!ch) { clearTimeout(forceTimer); $('#force-stop').hidden = true; }
  }

  function runOrStop() {
    if (!S.ready) { toast('Python is still starting\u2026'); return; }
    if (S.busy) { stopAll(); return; }
    S.errLine = 0; S.errTarget = null;
    positionOverlays();
    $('#go-error').hidden = true;
    if (S.cfg.clearOnRun) outCon.reset();
    else outCon.write('\n\u2500\u2500\u2500\u2500 new run \u2500\u2500\u2500\u2500\n', 'info');
    $('#out-empty').hidden = true;
    setStatus('run', 'Running\u2026');
    S.dirty = false; updateTitle();
    setBusy('run');
    showView('output');
    A.runFile(S.file, ta.value);
  }

  function stopAll() {
    if (!S.busy) return;
    S.stopping = true;
    A.stop();
    setStatus('run', 'Stopping\u2026');
    clearTimeout(forceTimer);
    forceTimer = setTimeout(function () { if (S.busy) $('#force-stop').hidden = false; }, 2500);
  }

  $('#btn-run').addEventListener('click', runOrStop);
  $('#force-stop').addEventListener('click', function () {
    ask({ title: 'Force restart?', message: 'The app restarts and the running code is killed. Saved files are kept.', ok: 'Restart', danger: true }).then(function (y) { if (y) A.restartApp(); });
  });
  $('#out-clear').addEventListener('click', function () { outCon.reset(); $('#out-empty').hidden = false; });

  function gotoLine(line) {
    showView('editor');
    var v = ta.value, pos = 0;
    for (var i = 1; i < line; i++) { var n = v.indexOf('\n', pos); if (n < 0) break; pos = n + 1; }
    ta.setSelectionRange(pos, pos);
    scroller.scrollTop = Math.max(0, PAD + (line - 1) * LH - scroller.clientHeight / 3);
    scheduleCaret();
  }
  $('#go-error').addEventListener('click', function () {
    var t = S.errTarget;
    if (!t) return;
    if (t.file !== S.file) { if (!openFile(t.file)) return; S.errLine = t.line; positionOverlays(); }
    gotoLine(t.line);
  });

  // inputs requested by programs (input())
  function hideAwaiting() {
    S.awaiting = null;
    $('#out-input-bar').hidden = true;
    outInput.value = '';
    $('#term-prompt').textContent = S.prompt.trim();
  }
  $('#out-input-bar').addEventListener('submit', function (e) {
    e.preventDefault();
    if (!S.awaiting) return;
    var t = outInput.value;
    outCon.write(t + '\n', 'cmd');
    outInput.value = '';
    A.submitInput(t);
    S.awaiting = null;
    $('#out-input-bar').hidden = true;
  });

  // ------------------------------------------------------------------
  // Terminal
  // ------------------------------------------------------------------
  function termExec(line) {
    termInput.value = line;
    termSubmit();
  }

  function termSubmit() {
    var line = termInput.value;
    if (S.awaiting && S.awaiting.channel === 'term') {
      termCon.write(line + '\n', 'cmd');
      termInput.value = '';
      A.submitInput(line);
      S.awaiting = null;
      $('#term-prompt').textContent = S.prompt.trim();
      return;
    }
    if (S.busy) { toast('A command is running \u2013 tap Ctrl-C to stop it'); return; }
    if (!S.ready) { toast('Python is still starting\u2026'); return; }
    termInput.value = '';
    termCon.echo(S.prompt, line);
    if (line.trim()) {
      if (S.hist[S.hist.length - 1] !== line) S.hist.push(line);
      if (S.hist.length > 100) S.hist.shift();
      LS.set('hist', S.hist);
    }
    S.histPos = -1;
    if (line.trim() === 'history' && !S.repl) {
      termCon.write(S.hist.map(function (h, i) { return ('     ' + (i + 1)).slice(-5) + '  ' + h; }).join('\n') + '\n', 'stdout');
      return;
    }
    if (!line.trim()) return;
    setBusy('term');
    A.shell(line);
  }
  $('#term-form').addEventListener('submit', function (e) { e.preventDefault(); termSubmit(); });

  function histMove(dir) {
    if (!S.hist.length) return;
    if (S.histPos === -1) { S.histDraft = termInput.value; S.histPos = S.hist.length; }
    S.histPos = Math.max(0, Math.min(S.hist.length, S.histPos + dir));
    termInput.value = S.histPos === S.hist.length ? S.histDraft : S.hist[S.histPos];
  }

  function termTab() {
    if (S.busy || !S.ready) return;
    var v = termInput.value;
    var list = jparse(A.complete(v), []);
    if (!list.length) return;
    var parts = v.split(' '), last = parts[parts.length - 1];
    if (list.length === 1) {
      parts[parts.length - 1] = list[0];
      termInput.value = parts.join(' ') + (/\/$/.test(list[0]) ? '' : ' ');
      return;
    }
    var common = list[0];
    list.forEach(function (x) { while (x.indexOf(common) !== 0) common = common.slice(0, -1); });
    termCon.echo(S.prompt, v);
    termCon.write(list.join('  ') + '\n', 'stdout');
    if (common.length > last.length) { parts[parts.length - 1] = common; termInput.value = parts.join(' '); }
  }

  function termCtrlC() {
    if (S.busy) { stopAll(); return; }
    termCon.echo(S.prompt, termInput.value + '^C');
    termInput.value = '';
  }

  termInput.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowUp') { e.preventDefault(); histMove(-1); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); histMove(1); }
    else if (e.key === 'Tab') { e.preventDefault(); termTab(); }
    else if (e.ctrlKey && (e.key === 'c' || e.key === 'C')) { e.preventDefault(); termCtrlC(); }
  });
  $('#term-keys').addEventListener('mousedown', function (e) { e.preventDefault(); });
  $('#term-keys').addEventListener('click', function (e) {
    var b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.tk === 'tab') termTab();
    else if (b.dataset.tk === 'up') histMove(-1);
    else if (b.dataset.tk === 'down') histMove(1);
    else if (b.dataset.tk === 'ctrlc') termCtrlC();
    else if (b.dataset.tkIns != null) { termInput.value += b.dataset.tkIns; termInput.focus(); }
    else if (b.dataset.tkRun != null) termExec(b.dataset.tkRun);
  });
  $('#term-clear').addEventListener('click', function () { termCon.reset(); });
  $('#repl-exit').addEventListener('click', function () {
    var p = A.leaveRepl();
    if (p) S.prompt = p;
    S.repl = false;
    $('#repl-exit').hidden = true;
    termCon.write('\n', 'stdout');
    $('#term-prompt').textContent = S.prompt.trim();
  });

  // ------------------------------------------------------------------
  // Image viewer
  // ------------------------------------------------------------------
  var viewerImg = null;
  function openViewer(url, title, name) {
    viewerImg = { url: url, title: title, name: name };
    $('#v-img').src = url;
    $('#v-title').textContent = title || 'Image';
    $('#v-scroll').classList.remove('zoom');
    $('#viewer').hidden = false;
  }
  $('#v-close').addEventListener('click', function () { $('#viewer').hidden = true; });
  $('#v-zoom').addEventListener('click', function () { $('#v-scroll').classList.toggle('zoom'); });
  $('#v-save').addEventListener('click', function () { if (viewerImg) A.exportOutput(viewerImg.name, viewerImg.name); });

  // ------------------------------------------------------------------
  // Callbacks invoked from Kotlin / Python
  // ------------------------------------------------------------------
  function badge(which) {
    var id = which === 'run' ? 'out' : 'term';
    var view = which === 'run' ? 'output' : 'term';
    if (S.view !== view) $('#badge-' + id).hidden = false;
  }

  var PS = window.PS = {
    onReady: function (json) {
      var info = jparse(json, { ok: false, error: 'bad payload' });
      if (!info.ok) {
        $('#boot-msg').textContent = 'Python failed to start';
        $('#boot-note').textContent = info.error || '';
        document.querySelector('#boot .spinner').style.display = 'none';
        return;
      }
      S.ready = true;
      S.python = info.python;
      S.workspace = info.workspace || (A.workspacePath && A.workspacePath()) || '';
      $('#boot').classList.add('hide');
      setTimeout(function () { $('#boot').style.display = 'none'; }, 400);
      termCon.write('\x1b[1;36mPyStudio terminal\x1b[0m  \u2022  Python ' + info.python + '\n', 'stdout');
      termCon.write('Type \x1b[1mhelp\x1b[0m for commands, e.g. \x1b[32mpip install rich\x1b[0m\n\n', 'stdout');
      var first = S.file;
      if (!A.fileExists(first)) first = 'main.py';
      if (!A.fileExists(first)) { A.writeFile(first, '# Welcome to PyStudio\nprint("Hello, world!")\n'); }
      openFile(first);
      PS.checkPendingOpen();
    },

    onText: function (channel, stream, text) {
      if (channel === 'run') {
        $('#out-empty').hidden = true;
        outCon.write(text, stream);
        badge('run');
      } else {
        if (stream === 'clear') { termCon.reset(); return; }
        if (stream === 'open') { openFile(relFromAbs(text)); return; }
        termCon.write(text, stream);
        badge('term');
      }
    },

    onImage: function (name, title) {
      var url = IMG_BASE + encodeURIComponent(name);
      $('#out-empty').hidden = true;
      outCon.addImage(url, title, {
        open: function () { openViewer(url, title, name); },
        save: function () { A.exportOutput(name, name); }
      });
      badge('run');
    },

    onDone: function (channel, status, seconds, errFile, errLineNo, prompt) {
      var wasStopping = S.stopping;
      setBusy(null);
      hideAwaiting();
      if (channel === 'run') {
        var t = seconds < 1 ? Math.round(seconds * 1000) + ' ms' : seconds.toFixed(2) + ' s';
        if (status === 'ok') setStatus('ok', 'Finished in ' + t);
        else if (status === 'stopped' || wasStopping) setStatus('err', 'Stopped');
        else if (status === 'exit') setStatus('err', 'Exited with error');
        else setStatus('err', 'Error');
        if (errLineNo > 0 && errFile) {
          var rel = relFromAbs(errFile);
          S.errTarget = { file: rel, line: errLineNo };
          if (rel === S.file) { S.errLine = errLineNo; positionOverlays(); }
          $('#go-error').textContent = 'Go to line ' + errLineNo;
          $('#go-error').hidden = false;
        }
      } else {
        if (prompt) S.prompt = prompt;
        S.repl = /^(>>>|\.\.\.)/.test(S.prompt);
        $('#repl-exit').hidden = !S.repl;
        $('#term-prompt').textContent = S.prompt.trim();
        if (S.view === 'term') termInput.focus();
      }
      if (S.view === 'editor' || channel === 'term') refreshFilesIfOpen();
    },

    onInputRequest: function (channel) {
      S.awaiting = { channel: channel };
      if (channel === 'run') {
        $('#out-input-bar').hidden = false;
        setTimeout(function () { outInput.focus(); outCon.scrollDown(); }, 60);
      } else {
        $('#term-prompt').textContent = 'input \u203A';
        termInput.focus();
      }
    },

    onPicked: function (id, mode, path, name, status) {
      var w = pickWaiters[id];
      delete pickWaiters[id];
      if (w) w({ path: path, name: name, status: status });
    },
    onPickProgress: function () { toast('Importing file\u2026'); },

    checkPendingOpen: function () {
      var n = A.takePendingOpen();
      if (n && S.ready) { openFile(n); toast('Opened ' + n); }
    },

    onPause: function () { if (S.dirty) saveFile(true); },

    onBack: function () {
      if (!$('#viewer').hidden) { $('#viewer').hidden = true; return true; }
      if (!$('#dialog').hidden) { closeDialog(null); return true; }
      if (closeSheets()) return true;
      if (!$('#findbar').hidden) { $('#findbar').hidden = true; clearFind(); return true; }
      if (S.view !== 'editor') { showView('editor'); return true; }
      if (S.dirty) saveFile(true);
      return false;
    }
  };

  function refreshFilesIfOpen() {
    if ($('#sheet-files').classList.contains('open')) refreshFiles();
  }

  document.addEventListener('visibilitychange', function () { if (document.hidden && S.dirty) saveFile(true); });

  // ------------------------------------------------------------------
  // Boot
  // ------------------------------------------------------------------
  applyCfg();
  updateTitle();
  render();
  onCaret();
  A.ready();
})();

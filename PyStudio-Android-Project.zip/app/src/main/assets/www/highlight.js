/* PyStudio - Python syntax highlighter and code analysis helpers (no dependencies). */
(function (global) {
  'use strict';

  var KEYWORDS = new Set(('and as assert async await break class continue def del elif else except finally for ' +
    'from global if import in is lambda nonlocal not or pass raise return try while with yield').split(' '));
  var CONSTANTS = new Set(['True', 'False', 'None', '__name__', '__file__']);
  var BUILTINS = new Set(('abs all any ascii bin bool bytearray bytes callable chr classmethod compile complex ' +
    'delattr dict dir divmod enumerate eval exec filter float format frozenset getattr globals hasattr hash help ' +
    'hex id input int isinstance issubclass iter len list locals map max memoryview min next object oct open ord ' +
    'pow print property range repr reversed round set setattr slice sorted staticmethod str sum super tuple type ' +
    'vars zip').split(' '));

  var RX = new RegExp(
    '(#[^\\n]*)' +                                                     // 1 comment
    '|((?:[rRbBuUfF]{1,2})?(?:"""[\\s\\S]*?(?:"""|$)' +                // 2 strings
    "|'''[\\s\\S]*?(?:'''|$)" +
    '|"(?:\\\\[\\s\\S]|[^"\\\\\\n])*(?:"|(?=\\n)|$)' +
    "|'(?:\\\\[\\s\\S]|[^'\\\\\\n])*(?:'|(?=\\n)|$)))" +
    '|(@[A-Za-z_][\\w.]*)' +                                           // 3 decorator
    '|(\\b0[xX][\\da-fA-F_]+|\\b0[bB][01_]+|\\b0[oO][0-7_]+|\\b\\d[\\d_]*\\.?[\\d_]*(?:[eE][+-]?\\d+)?[jJ]?|\\.\\d[\\d_]*(?:[eE][+-]?\\d+)?[jJ]?)' + // 4 number
    '|([A-Za-z_]\\w*)',                                                // 5 identifier
    'g'
  );

  function esc(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function highlight(text) {
    var out = '', last = 0, prevWord = '', m;
    RX.lastIndex = 0;
    while ((m = RX.exec(text)) !== null) {
      if (m[0].length === 0) { RX.lastIndex++; continue; }
      if (m.index > last) {
        var gap = text.slice(last, m.index);
        out += esc(gap);
        if (/\S/.test(gap.replace(/\s+/g, ''))) prevWord = '';
      }
      var t = m[0], cls = '';
      if (m[1]) { cls = 'c'; prevWord = ''; }
      else if (m[2]) { cls = 's'; prevWord = ''; }
      else if (m[3]) { cls = 'd'; prevWord = ''; }
      else if (m[4]) { cls = 'n'; prevWord = ''; }
      else {
        var next = text.charAt(m.index + t.length);
        if (CONSTANTS.has(t)) cls = 'k2';
        else if (KEYWORDS.has(t)) cls = 'k';
        else if (t === 'self' || t === 'cls') cls = 'sf';
        else if (prevWord === 'def') cls = 'fd';
        else if (prevWord === 'class') cls = 'cd';
        else if (next === '(') cls = BUILTINS.has(t) ? 'b' : 'fn';
        else if (BUILTINS.has(t)) cls = 'b';
        else if (/^[A-Z][a-z0-9]\w*$/.test(t) || /(Error|Exception|Warning)$/.test(t)) cls = 'cd';
        prevWord = t;
      }
      last = m.index + t.length;
      out += cls ? '<span class="t-' + cls + '">' + esc(t) + '</span>' : esc(t);
    }
    if (last < text.length) out += esc(text.slice(last));
    return out;
  }

  // ------------------------------------------------------------------
  // Call detection (used by the "Pick file" button)
  // ------------------------------------------------------------------
  var NOT_CALLS = new Set(['if', 'elif', 'while', 'return', 'in', 'and', 'or', 'not', 'is', 'assert', 'lambda',
    'yield', 'await', 'else', 'for', 'with', 'del', 'raise', 'from', 'import', 'as', 'except', 'print_']);

  /** Name of the callee for the "(" at index openIdx, or null if it is not a call. */
  function calleeName(text, openIdx) {
    var j = openIdx - 1;
    while (j >= 0 && (text[j] === ' ' || text[j] === '\t')) j--;
    if (j < 0) return null;
    var ch = text[j];
    if (ch === ')' || ch === ']') return '\u2026';
    if (!/[\w]/.test(ch)) return null;
    var head = text.slice(Math.max(0, j - 100), j + 1);
    var m = /[A-Za-z_][\w.]*$/.exec(head);
    if (!m) return null;
    var name = m[0];
    if (NOT_CALLS.has(name)) return null;
    var before = head.slice(0, head.length - name.length);
    if (/\b(def|class)\s+$/.test(before)) return null;
    return name;
  }

  /** Reads a string literal that starts at index i. */
  function readString(text, i) {
    var c = text[i];
    var triple = text.substr(i, 3) === c + c + c;
    var q = triple ? c + c + c : c;
    var j = i + q.length, closed = -1, n = text.length;
    while (j < n) {
      var ch = text[j];
      if (ch === '\\') { j += 2; continue; }
      if (!triple && ch === '\n') break;
      if (text.substr(j, q.length) === q) { closed = j; break; }
      j++;
    }
    var end = closed >= 0 ? closed + q.length : Math.min(j, n);
    return { start: i, end: end, closed: closed, qlen: q.length, quote: q };
  }

  /**
   * Analyses the text before `pos`.
   * Returns { call: {name, open} | null, str: {start, end, ...} | null, comment: bool }
   */
  function scan(text, pos) {
    var stack = [], i = 0, n = text.length, str = null;
    if (pos > n) pos = n;
    while (i < pos) {
      var c = text[i];
      if (c === '#') {
        var e = text.indexOf('\n', i);
        if (e < 0) e = n;
        if (pos <= e) return { call: null, str: null, comment: true };
        i = e;
        continue;
      }
      if (c === '"' || c === "'") {
        var s = readString(text, i);
        var contentEnd = s.closed >= 0 ? s.closed : s.end;
        if (pos > i && pos <= contentEnd) { str = s; break; }
        i = Math.max(s.end, i + 1);
        continue;
      }
      if (c === '(' || c === '[' || c === '{') stack.push({ c: c, i: i });
      else if (c === ')' || c === ']' || c === '}') stack.pop();
      i++;
    }
    for (var k = stack.length - 1; k >= 0; k--) {
      if (stack[k].c === '(') {
        var name = calleeName(text, stack[k].i);
        if (name) return { call: { name: name, open: stack[k].i }, str: str, comment: false };
      }
    }
    return { call: null, str: str, comment: false };
  }

  /** Index of the ")" matching the "(" at openIdx, or -1. */
  function findClose(text, openIdx) {
    var depth = 0, i = openIdx, n = text.length;
    while (i < n) {
      var c = text[i];
      if (c === '#') { var e = text.indexOf('\n', i); i = e < 0 ? n : e; continue; }
      if (c === '"' || c === "'") { i = Math.max(readString(text, i).end, i + 1); continue; }
      if (c === '(' || c === '[' || c === '{') depth++;
      else if (c === ')' || c === ']' || c === '}') {
        depth--;
        if (depth === 0) return i;
      }
      i++;
    }
    return -1;
  }

  function quote(path) {
    return '"' + path.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
  }

  /**
   * Decides how to insert `path` for the cursor at [selStart, selEnd].
   * Returns { start, end, text, caret } describing the replacement.
   */
  function planPathInsert(text, selStart, selEnd, path) {
    var q = quote(path);
    var info = scan(text, selStart);
    if (info.str) {
      return { start: info.str.start, end: info.str.end, text: q, caret: info.str.start + q.length, inCall: !!info.call };
    }
    if (info.call) {
      var close = findClose(text, info.call.open);
      var inner = close >= 0 ? text.slice(info.call.open + 1, close) : '';
      if (close >= 0 && inner.trim() === '') {
        return { start: info.call.open + 1, end: close, text: q, caret: info.call.open + 1 + q.length, inCall: true };
      }
      var k = selStart - 1;
      while (k > info.call.open && /\s/.test(text[k])) k--;
      var prev = text[k];
      var prefix = '';
      if (prev !== '(' && prev !== ',' && prev !== '=' && k > info.call.open) prefix = ', ';
      else if (prev === ',' && !/\s/.test(text.charAt(selStart - 1))) prefix = ' ';
      return { start: selStart, end: selEnd, text: prefix + q, caret: selStart + prefix.length + q.length, inCall: true };
    }
    return { start: selStart, end: selEnd, text: q, caret: selStart + q.length, inCall: false };
  }

  global.PSCode = { highlight: highlight, scan: scan, planPathInsert: planPathInsert, findClose: findClose, quote: quote };
})(window);

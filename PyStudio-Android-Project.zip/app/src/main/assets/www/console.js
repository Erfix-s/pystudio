/* PyStudio - console renderer with ANSI colours, carriage-return overwrite and inline images. */
(function (global) {
  'use strict';

  var SPLIT = /(\x1b\[[0-9;?]*[A-Za-z]|\r\n|\n|\r)/;

  function Con(el, maxLines) {
    this.el = el;
    this.max = maxLines || 3000;
    this.reset();
  }

  Con.prototype.reset = function () {
    this.el.textContent = '';
    this.count = 0;
    this.style = { fg: '', bold: false, dim: false, italic: false, underline: false };
    this.line = null;
    this.newLine();
  };

  Con.prototype.newLine = function () {
    var d = document.createElement('div');
    d.className = 'cl';
    this.el.appendChild(d);
    this.line = d;
    this.count++;
    if (this.count > this.max) {
      var drop = this.count - this.max;
      while (drop-- > 0 && this.el.firstChild && this.el.firstChild !== this.line) {
        this.el.removeChild(this.el.firstChild);
        this.count--;
      }
    }
  };

  Con.prototype.nearBottom = function () {
    var e = this.el;
    return e.scrollHeight - e.scrollTop - e.clientHeight < 80;
  };

  Con.prototype.scrollDown = function () {
    this.el.scrollTop = this.el.scrollHeight;
  };

  Con.prototype.cls = function (stream) {
    var s = this.style, c = 's-' + (stream || 'stdout');
    if (s.fg) c += ' a-' + s.fg;
    if (s.bold) c += ' a-b';
    if (s.dim) c += ' a-dim';
    if (s.italic) c += ' a-i';
    if (s.underline) c += ' a-u';
    return c;
  };

  Con.prototype.sgr = function (params) {
    var s = this.style;
    var codes = params === '' ? [0] : params.split(';').map(function (x) { return parseInt(x || '0', 10); });
    for (var i = 0; i < codes.length; i++) {
      var n = codes[i];
      if (n === 0) { s.fg = ''; s.bold = s.dim = s.italic = s.underline = false; }
      else if (n === 1) s.bold = true;
      else if (n === 2) s.dim = true;
      else if (n === 3) s.italic = true;
      else if (n === 4) s.underline = true;
      else if (n === 22) { s.bold = false; s.dim = false; }
      else if (n === 23) s.italic = false;
      else if (n === 24) s.underline = false;
      else if ((n >= 30 && n <= 37) || (n >= 90 && n <= 97)) s.fg = String(n);
      else if (n === 39) s.fg = '';
      else if (n === 38 || n === 48) { i += (codes[i + 1] === 5) ? 2 : 4; }
    }
  };

  Con.prototype.write = function (text, stream) {
    if (!text) return;
    var stick = this.nearBottom();
    var parts = text.split(SPLIT);
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (!p) continue;
      if (p === '\n' || p === '\r\n') { this.newLine(); continue; }
      if (p === '\r') { this.line.textContent = ''; continue; }
      if (p.charCodeAt(0) === 27) {
        var last = p.charAt(p.length - 1);
        if (last === 'm') this.sgr(p.slice(2, -1));
        else if (last === 'K' || last === 'J') this.line.textContent = '';
        continue;
      }
      this.append(p, this.cls(stream));
    }
    if (stick) this.scrollDown();
  };

  Con.prototype.append = function (text, cls) {
    var lastChild = this.line.lastChild;
    if (lastChild && lastChild.className === cls) {
      lastChild.textContent += text;
    } else {
      var sp = document.createElement('span');
      sp.className = cls;
      sp.textContent = text;
      this.line.appendChild(sp);
    }
  };

  /** Echo a typed command (terminal) or typed input (program). */
  Con.prototype.echo = function (prompt, text) {
    if (this.line.childNodes.length && prompt) this.newLine();
    if (prompt) this.append(prompt, 's-prompt');
    this.append(text, 's-cmd');
    this.newLine();
    this.scrollDown();
  };

  Con.prototype.addImage = function (url, title, actions) {
    if (this.line.childNodes.length) this.newLine();
    var card = document.createElement('div');
    card.className = 'img-card';
    var img = document.createElement('img');
    img.src = url;
    img.alt = title || 'image';
    img.loading = 'eager';
    img.addEventListener('click', function () { if (actions && actions.open) actions.open(); });
    var cap = document.createElement('div');
    cap.className = 'cap';
    var label = document.createElement('span');
    label.textContent = title || 'Image';
    var btns = document.createElement('span');
    btns.className = 'cap-btns';
    var b1 = document.createElement('button');
    b1.textContent = 'View';
    b1.addEventListener('click', function () { if (actions && actions.open) actions.open(); });
    var b2 = document.createElement('button');
    b2.textContent = 'Save';
    b2.addEventListener('click', function () { if (actions && actions.save) actions.save(); });
    btns.appendChild(b1);
    btns.appendChild(b2);
    cap.appendChild(label);
    cap.appendChild(btns);
    card.appendChild(img);
    card.appendChild(cap);
    var stick = this.nearBottom();
    this.el.insertBefore(card, this.line);
    img.addEventListener('load', (function (self) { return function () { if (stick) self.scrollDown(); }; })(this));
    this.count++;
    if (stick) this.scrollDown();
  };

  Con.prototype.isEmpty = function () {
    return this.el.children.length <= 1 && !this.line.childNodes.length;
  };

  global.PSConsole = Con;
})(window);

"""Matplotlib backend for PyStudio.

Draws with Agg (so everything works headless on Android) and turns
``plt.show()`` into an image shown in the app's Output tab.
"""
from matplotlib.backend_bases import FigureManagerBase
from matplotlib.backends.backend_agg import FigureCanvasAgg

FigureCanvas = FigureCanvasAgg


class FigureManager(FigureManagerBase):
    def show(self):  # nothing to do, rendering happens in show() below
        pass


def new_figure_manager(num, *args, FigureClass=None, **kwargs):
    if FigureClass is None:
        from matplotlib.figure import Figure as FigureClass
    fig = FigureClass(*args, **kwargs)
    return new_figure_manager_given_figure(num, fig)


def new_figure_manager_given_figure(num, figure):
    canvas = FigureCanvas(figure)
    return FigureManager(canvas, num)


def draw_if_interactive():
    pass


def show(*args, block=None, **kwargs):
    if block is False:  # plt.pause() / animations: do not spam images
        return
    import pystudio_core

    pystudio_core.emit_open_figures(close=True)

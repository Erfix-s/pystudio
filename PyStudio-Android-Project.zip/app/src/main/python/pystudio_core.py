"""PyStudio runtime core.

Runs on-device inside Chaquopy (CPython 3.10).  It provides

* a script runner with live stdout/stderr streaming, input() support,
  traceback cleaning and "Stop" support,
* patches so that ``plt.show()``, ``cv2.imshow()`` and ``PIL.Image.show()``
  render as images in the Output tab,
* a small Linux-like shell (ls, cd, cat, python, pip, ...),
* a pure-Python ``pip`` that installs pure-Python wheels from PyPI into
  an app-private site-packages directory.

Everything talks to the Kotlin side through a ``sink`` object.
"""
import builtins
import code as _code
import contextlib
import ctypes
import fnmatch
import hashlib
import importlib
import io
import itertools
import json
import os
import platform
import re
import shlex
import shutil
import sys
import threading
import time
import traceback
import urllib.error
import urllib.request
import zipfile

APP_VERSION = "1.0"

HOME = os.environ.get("HOME") or os.path.expanduser("~") or "/data/local/tmp"
WORKSPACE = os.path.join(HOME, "workspace")
SITE = os.path.join(HOME, "site-packages")
OUT = os.path.join(HOME, "out")

_sink = None
_state = {"cwd": WORKSPACE, "thread_id": None, "repl": None, "env": {}}
_counter = itertools.count(1)
_run_images = [0]
_patched = set()
_run_lock = threading.Lock()

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp")


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------
def setup(out_dir, sink):
    """Called once by Kotlin after Python has started."""
    global OUT, _sink
    OUT = out_dir
    _sink = sink
    for d in (WORKSPACE, SITE, OUT, os.path.join(HOME, ".mplconfig")):
        os.makedirs(d, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = os.path.join(HOME, ".mplconfig")
    os.environ["MPLBACKEND"] = "module://pystudio_mpl_backend"
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    os.environ["PYSTUDIO_WORKSPACE"] = WORKSPACE
    if SITE not in sys.path:
        sys.path.append(SITE)
    importlib.invalidate_caches()
    try:
        os.chdir(WORKSPACE)
    except OSError:
        pass
    return info()


def info():
    return json.dumps(
        {
            "python": platform.python_version(),
            "workspace": WORKSPACE,
            "site": SITE,
            "machine": platform.machine(),
            "app": APP_VERSION,
        }
    )


# ---------------------------------------------------------------------------
# Buffered output streams
# ---------------------------------------------------------------------------
class _Out:
    """Collects text and forwards it to the UI in small batches."""

    def __init__(self, channel):
        self.channel = channel
        self.lock = threading.Lock()
        self.send_lock = threading.RLock()
        self.items = []
        self.size = 0
        self.timer = None

    def put(self, stream, text):
        if not text:
            return
        big = False
        with self.lock:
            if self.items and self.items[-1][0] == stream:
                self.items[-1][1] += text
            else:
                self.items.append([stream, text])
            self.size += len(text)
            if self.size > 16384:
                big = True
            elif self.timer is None:
                self.timer = threading.Timer(0.04, self.flush)
                self.timer.daemon = True
                self.timer.start()
        if big:
            self.flush()

    def flush(self):
        with self.send_lock:
            with self.lock:
                items, self.items, self.size = self.items, [], 0
                timer, self.timer = self.timer, None
            if timer is not None and timer is not threading.current_thread():
                timer.cancel()
            for stream, text in items:
                try:
                    _sink.onText(self.channel, stream, text)
                except Exception:
                    pass


class _TextOut(io.TextIOBase):
    encoding = "utf-8"
    errors = "replace"

    def __init__(self, out, stream):
        super().__init__()
        self._o = out
        self._s = stream

    def writable(self):
        return True

    def isatty(self):
        return False

    def write(self, s):
        if not isinstance(s, str):
            s = str(s)
        self._o.put(self._s, s)
        return len(s)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        self._o.flush()


class _Stdin(io.TextIOBase):
    """sys.stdin backed by the Output/Terminal input bar."""

    encoding = "utf-8"
    errors = "replace"

    def __init__(self, out):
        super().__init__()
        self._o = out

    def readable(self):
        return True

    def isatty(self):
        return False

    def readline(self, size=-1):
        self._o.flush()
        line = _sink.requestInput(self._o.channel)
        if line is None:
            return ""
        return line + "\n"

    def read(self, size=-1):
        chunks = []
        while True:
            line = self.readline()
            if not line:
                break
            chunks.append(line)
        return "".join(chunks)

    def __iter__(self):
        return self

    def __next__(self):
        line = self.readline()
        if not line:
            raise StopIteration
        return line


@contextlib.contextmanager
def _redirect(channel):
    out = _Out(channel)
    saved = (sys.stdout, sys.stderr, sys.stdin, builtins.input)
    stdin = _Stdin(out)

    def _input(prompt=""):
        if prompt:
            sys.stdout.write(str(prompt))
        out.flush()
        line = stdin.readline()
        if not line:
            raise EOFError("EOF when reading a line")
        return line[:-1] if line.endswith("\n") else line

    sys.stdout = _TextOut(out, "stdout")
    sys.stderr = _TextOut(out, "stderr")
    sys.stdin = stdin
    builtins.input = _input
    try:
        yield out
    finally:
        out.flush()
        sys.stdout, sys.stderr, sys.stdin, builtins.input = saved


# ---------------------------------------------------------------------------
# Images (Output tab)
# ---------------------------------------------------------------------------
def new_out_path(ext="png"):
    os.makedirs(OUT, exist_ok=True)
    return os.path.join(OUT, "img_%d_%d.%s" % (next(_counter), int(time.time() * 1000) % 100000000, ext))


def emit_image(path, title=""):
    """Show an image file in the Output tab (copied into the web-visible dir)."""
    if os.path.dirname(os.path.abspath(path)) != os.path.abspath(OUT):
        ext = os.path.splitext(path)[1].lstrip(".").lower() or "png"
        dst = new_out_path(ext)
        shutil.copyfile(path, dst)
        path = dst
    _run_images[0] += 1
    _sink.onImage(os.path.basename(path), title or "")


def emit_open_figures(close=True):
    """Render every open Matplotlib figure into the Output tab."""
    if "matplotlib" not in sys.modules:
        return 0
    try:
        from matplotlib._pylab_helpers import Gcf
    except Exception:
        return 0
    count = 0
    for mgr in list(Gcf.get_all_fig_managers()):
        try:
            fig = mgr.canvas.figure
            path = new_out_path("png")
            fig.savefig(path, dpi=140, bbox_inches="tight", facecolor=fig.get_facecolor())
            title = ""
            try:
                title = fig._suptitle.get_text() if fig._suptitle is not None else ""
                if not title and fig.axes:
                    title = fig.axes[0].get_title()
            except Exception:
                pass
            emit_image(path, title or "Figure %s" % mgr.num)
            count += 1
        except Exception as exc:  # pragma: no cover
            sys.stderr.write("Could not render figure: %s\n" % exc)
    if close:
        try:
            Gcf.destroy_all()
        except Exception:
            pass
    return count


def _patch_cv2():
    import cv2
    import numpy as np

    def imshow(winname, mat):
        arr = np.asarray(mat)
        if arr.dtype != np.uint8:
            if arr.dtype.kind == "f":
                arr = np.clip(np.nan_to_num(arr) * 255.0, 0, 255).astype(np.uint8)
            elif arr.dtype == np.uint16:
                arr = (arr >> 8).astype(np.uint8)
            else:
                arr = np.clip(arr, 0, 255).astype(np.uint8)
        if arr.ndim == 3 and arr.shape[2] == 1:
            arr = arr[:, :, 0]
        path = new_out_path("png")
        if not cv2.imwrite(path, arr):
            raise ValueError("cv2.imshow: unsupported image shape %r" % (arr.shape,))
        emit_image(path, str(winname))

    def _wait(delay=0):
        # Returns 'q' so "while True ... if cv2.waitKey(1) == ord('q')" loops end.
        return 113

    noop = lambda *a, **k: None
    cv2.imshow = imshow
    cv2.waitKey = _wait
    cv2.waitKeyEx = _wait
    for name in (
        "destroyAllWindows", "destroyWindow", "namedWindow", "moveWindow",
        "resizeWindow", "setMouseCallback", "startWindowThread", "setWindowTitle",
    ):
        setattr(cv2, name, noop)


def _patch_pil():
    from PIL import Image

    def show(self, title=None, **kwargs):
        img = self
        if img.mode not in ("1", "L", "LA", "P", "RGB", "RGBA"):
            img = img.convert("RGB")
        path = new_out_path("png")
        img.save(path, "PNG")
        emit_image(path, title or "PIL image")

    Image.Image.show = show


def _ensure_patches(src):
    if "cv2" not in _patched and (re.search(r"\bcv2\b|opencv", src) or "cv2" in sys.modules):
        try:
            _patch_cv2()
            _patched.add("cv2")
        except ImportError:
            pass
        except Exception as exc:
            sys.stderr.write("[PyStudio] cv2 patch failed: %s\n" % exc)
    if "PIL" not in _patched and (re.search(r"\bPIL\b|pillow", src, re.I) or "PIL" in sys.modules):
        try:
            _patch_pil()
            _patched.add("PIL")
        except ImportError:
            pass
        except Exception as exc:
            sys.stderr.write("[PyStudio] PIL patch failed: %s\n" % exc)


# ---------------------------------------------------------------------------
# Script execution
# ---------------------------------------------------------------------------
def _snapshot(root):
    snap = {}
    n = 0
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if not d.startswith(".") and d != "__pycache__" and d != "inputs"]
        for f in fn:
            if f.startswith("."):
                continue
            p = os.path.join(dp, f)
            try:
                snap[p] = os.stat(p).st_mtime
            except OSError:
                pass
            n += 1
            if n > 3000:
                return snap
    return snap


def _print_exception(exc_info, path):
    etype, value, tb = exc_info
    while tb is not None and tb.tb_frame.f_globals.get("__name__") == __name__:
        tb = tb.tb_next
    err_line = 0
    if isinstance(value, SyntaxError) and value.lineno:
        err_line = value.lineno
    else:
        for frame, lineno in traceback.walk_tb(tb):
            if frame.f_code.co_filename == path:
                err_line = lineno
    try:
        text = "".join(traceback.format_exception(etype, value, tb))
    except Exception:
        text = "%s: %s\n" % (etype.__name__, value)
    sys.stderr.write(text)
    return err_line


def _sibling_sources(directory):
    chunks = []
    total = 0
    try:
        for name in os.listdir(directory):
            if name.endswith(".py"):
                with open(os.path.join(directory, name), "r", encoding="utf-8", errors="ignore") as fh:
                    data = fh.read(60000)
                chunks.append(data)
                total += len(data)
                if total > 300000:
                    break
    except OSError:
        pass
    return "\n".join(chunks)


def _execute(source, filename, argv, channel, workdir):
    """Run source in a fresh __main__ namespace. Returns (status, err_file, err_line)."""
    status, err_line = "ok", 0
    _state["thread_id"] = threading.get_ident()
    old_cwd, old_argv, old_path = os.getcwd(), sys.argv[:], sys.path[:]
    old_main = sys.modules.get("__main__")
    try:
        with _redirect(channel):
            try:
                os.makedirs(workdir, exist_ok=True)
                os.chdir(workdir)
                if workdir not in sys.path:
                    sys.path.insert(0, workdir)
                sys.argv = [filename] + list(argv)
                _ensure_patches(source + "\n" + _sibling_sources(workdir))
                glb = {
                    "__name__": "__main__",
                    "__file__": filename,
                    "__doc__": None,
                    "__builtins__": builtins,
                }
                try:
                    compiled = compile(source, filename, "exec")
                    exec(compiled, glb)
                except SystemExit as exc:
                    if exc.code not in (None, 0):
                        status = "exit"
                        sys.stderr.write("\nProcess exited with code %s\n" % (exc.code,))
                except KeyboardInterrupt:
                    status = "stopped"
                    sys.stderr.write("\nKeyboardInterrupt: execution stopped\n")
                except BaseException:
                    status = "error"
                    err_line = _print_exception(sys.exc_info(), filename)
            finally:
                try:
                    emit_open_figures(close=True)
                except BaseException:
                    pass
    finally:
        _state["thread_id"] = None
        try:
            os.chdir(old_cwd)
        except OSError:
            pass
        sys.argv = old_argv
        sys.path[:] = old_path
        if old_main is not None:
            sys.modules["__main__"] = old_main
    return status, (filename if err_line else ""), err_line


def _finish(channel, status, started, err_file="", err_line=0, prompt=""):
    try:
        _sink.onDone(channel, status, float(time.time() - started), err_file, int(err_line), prompt)
    except Exception:
        pass


def run_file(path):
    """Run a file from the editor (Output tab)."""
    started = time.time()
    status, err_file, err_line = "error", "", 0
    with _run_lock:
        _run_images[0] = 0
        try:
            _cleanup_out()
            before = _snapshot(WORKSPACE)
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                source = fh.read()
            status, err_file, err_line = _execute(source, path, [], "run", os.path.dirname(path))
            if status in ("ok", "exit"):
                _report_new_files(before, started)
        except BaseException as exc:  # never let the worker die silently
            _sink.onText("run", "stderr", "Internal error: %r\n" % (exc,))
    _finish("run", status, started, err_file, err_line)


def _cleanup_out():
    try:
        now = time.time()
        for f in os.listdir(OUT):
            p = os.path.join(OUT, f)
            if now - os.path.getmtime(p) > 3600:
                os.remove(p)
    except OSError:
        pass


def _report_new_files(before, started):
    """Mention files created by the script; show new images if none was displayed."""
    after = _snapshot(WORKSPACE)
    created = [p for p, m in after.items() if p not in before or m > before[p] + 0.0005]
    created.sort()
    shown = 0
    for p in created[:12]:
        rel = os.path.relpath(p, WORKSPACE)
        if rel.endswith(".py") or rel.endswith(".pyc"):
            continue
        _sink.onText("run", "info", "\u2714 Saved file: %s\n" % rel)
        if p.lower().endswith(IMAGE_EXT) and _run_images[0] == 0 and shown < 6:
            try:
                emit_image(p, rel)
                shown += 1
            except Exception:
                pass


def request_stop():
    """Raise KeyboardInterrupt inside the running Python thread."""
    tid = _state.get("thread_id")
    if tid is None:
        return False
    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(tid), ctypes.py_object(KeyboardInterrupt))
    return res > 0


# ---------------------------------------------------------------------------
# Shell
# ---------------------------------------------------------------------------
HELP = """PyStudio terminal - available commands

  File system   ls  cd  pwd  cat  head  tail  wc  touch  mkdir  rm  rmdir  cp  mv
                find  grep  tree  du  unzip  edit <file>
  Network       wget <url> [-O file]   curl [-o file | -O] <url>
  Python        python [file.py | -c "code" | -m pip ...]   (no args = REPL)
  Packages      pip install | uninstall | list | show | freeze   <package>
  Misc          echo  env  export  which  date  uname  whoami  clear  history  help

Tips: "~" is your workspace folder.  Redirect with > and >>.
      Tap Tab for completion, Ctrl-C to stop a running command.
"""


def _short_cwd():
    cwd = _state["cwd"]
    if cwd == WORKSPACE:
        return "~"
    if cwd.startswith(WORKSPACE + os.sep):
        return "~/" + os.path.relpath(cwd, WORKSPACE)
    return cwd


def _prompt():
    if _state["repl"] is not None:
        return _state["repl"]["prompt"]
    return "pystudio:%s $ " % _short_cwd()


def _resolve(p):
    if p == "~" or p.startswith("~/"):
        p = WORKSPACE + p[1:]
    if not os.path.isabs(p):
        p = os.path.join(_state["cwd"], p)
    return os.path.normpath(p)


class _Ctx:
    def __init__(self, out):
        self.out = out
        self.capture = None

    def w(self, text):
        if self.capture is not None:
            self.capture.append(text)
        else:
            self.out.put("stdout", text)

    def e(self, text):
        self.out.put("stderr", text)


def _human(n):
    for unit in ("B", "K", "M", "G"):
        if n < 1024 or unit == "G":
            return ("%d%s" % (n, unit)) if unit == "B" else ("%.1f%s" % (n, unit))
        n /= 1024.0


def _color(text, code):
    return "\x1b[%sm%s\x1b[0m" % (code, text)


def _fmt_entry(path, name, long=False, human=False):
    is_dir = os.path.isdir(path)
    shown = _color(name + "/", "1;34") if is_dir else (_color(name, "32") if name.endswith(".py") else name)
    if not long:
        return shown
    try:
        st = os.stat(path)
        size = _human(st.st_size) if human else str(st.st_size)
        ts = time.strftime("%b %d %H:%M", time.localtime(st.st_mtime))
    except OSError:
        size, ts = "?", "?"
    return "%s %8s %s %s" % ("d" if is_dir else "-", size, ts, shown)


def _opts(args, flags_with_value=()):
    flags, rest, i = set(), [], 0
    values = {}
    while i < len(args):
        a = args[i]
        if a == "--":
            rest.extend(args[i + 1:])
            break
        if a.startswith("-") and len(a) > 1 and not a[1:].isdigit():
            if a in flags_with_value and i + 1 < len(args):
                values[a] = args[i + 1]
                i += 2
                continue
            if a.startswith("--"):
                flags.add(a)
            else:
                flags.update("-" + c for c in a[1:])
        else:
            rest.append(a)
        i += 1
    return flags, rest, values


def c_help(c, a):
    c.w(HELP)


def c_pwd(c, a):
    c.w(_state["cwd"] + "\n")


def c_cd(c, a):
    target = _resolve(a[0] if a else "~")
    if not os.path.isdir(target):
        c.e("cd: %s: No such directory\n" % (a[0] if a else target))
        return 1
    _state["cwd"] = target


def c_ls(c, a):
    flags, paths, _ = _opts(a)
    paths = paths or ["."]
    for idx, p in enumerate(paths):
        full = _resolve(p)
        if not os.path.exists(full):
            c.e("ls: cannot access '%s': No such file or directory\n" % p)
            continue
        if len(paths) > 1:
            c.w(("\n" if idx else "") + p + ":\n")
        if os.path.isdir(full):
            names = sorted(os.listdir(full), key=str.lower)
            if "-a" not in flags:
                names = [n for n in names if not n.startswith(".")]
            if "-l" in flags:
                for n in names:
                    c.w(_fmt_entry(os.path.join(full, n), n, True, "-h" in flags) + "\n")
            elif names:
                c.w("  ".join(_fmt_entry(os.path.join(full, n), n) for n in names) + "\n")
        else:
            c.w(_fmt_entry(full, os.path.basename(full), "-l" in flags, "-h" in flags) + "\n")


def _read_text(c, name):
    try:
        with open(_resolve(name), "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except IsADirectoryError:
        c.e("%s: Is a directory\n" % name)
    except OSError as exc:
        c.e("%s: %s\n" % (name, exc.strerror or exc))
    return None


def c_cat(c, a):
    for name in a:
        t = _read_text(c, name)
        if t is not None:
            c.w(t if t.endswith("\n") or not t else t + "\n")


def _nopt(a, default=10):
    flags, rest, vals = _opts(a, ("-n",))
    n = default
    if "-n" in vals:
        try:
            n = int(vals["-n"])
        except ValueError:
            pass
    for f in flags:
        if f[1:].isdigit():
            n = int(f[1:])
    return n, rest


def c_head(c, a):
    n, files = _nopt(a)
    for name in files:
        t = _read_text(c, name)
        if t is not None:
            c.w("\n".join(t.splitlines()[:n]) + "\n")


def c_tail(c, a):
    n, files = _nopt(a)
    for name in files:
        t = _read_text(c, name)
        if t is not None:
            c.w("\n".join(t.splitlines()[-n:]) + "\n")


def c_wc(c, a):
    flags, files, _ = _opts(a)
    for name in files:
        t = _read_text(c, name)
        if t is None:
            continue
        lines, words, chars = t.count("\n"), len(t.split()), len(t.encode("utf-8"))
        if "-l" in flags:
            c.w("%d %s\n" % (lines, name))
        else:
            c.w("%7d %7d %7d %s\n" % (lines, words, chars, name))


def c_echo(c, a):
    flags = set()
    while a and a[0] in ("-n", "-e"):
        flags.add(a.pop(0))
    text = " ".join(a)
    if "-e" in flags:
        text = text.encode("utf-8").decode("unicode_escape", errors="ignore")
    c.w(text + ("" if "-n" in flags else "\n"))


def c_touch(c, a):
    for name in a:
        p = _resolve(name)
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "a"):
                os.utime(p, None)
        except OSError as exc:
            c.e("touch: %s: %s\n" % (name, exc.strerror))


def c_mkdir(c, a):
    flags, paths, _ = _opts(a)
    for name in paths:
        try:
            if "-p" in flags:
                os.makedirs(_resolve(name), exist_ok=True)
            else:
                os.mkdir(_resolve(name))
        except OSError as exc:
            c.e("mkdir: cannot create directory '%s': %s\n" % (name, exc.strerror))


def c_rmdir(c, a):
    for name in a:
        try:
            os.rmdir(_resolve(name))
        except OSError as exc:
            c.e("rmdir: failed to remove '%s': %s\n" % (name, exc.strerror))


def c_rm(c, a):
    flags, paths, _ = _opts(a)
    recursive = "-r" in flags or "-R" in flags
    for name in paths:
        p = _resolve(name)
        if p in (WORKSPACE, HOME, "/"):
            c.e("rm: refusing to remove '%s'\n" % name)
            continue
        try:
            if os.path.isdir(p) and not os.path.islink(p):
                if recursive:
                    shutil.rmtree(p)
                else:
                    c.e("rm: cannot remove '%s': Is a directory (use -r)\n" % name)
            else:
                os.remove(p)
        except OSError as exc:
            if "-f" not in flags:
                c.e("rm: cannot remove '%s': %s\n" % (name, exc.strerror))


def c_cp(c, a):
    flags, paths, _ = _opts(a)
    if len(paths) < 2:
        c.e("cp: missing destination\n")
        return 1
    dst = _resolve(paths[-1])
    for name in paths[:-1]:
        src = _resolve(name)
        try:
            if os.path.isdir(src):
                if "-r" not in flags and "-R" not in flags:
                    c.e("cp: -r not specified; omitting directory '%s'\n" % name)
                    continue
                target = os.path.join(dst, os.path.basename(src)) if os.path.isdir(dst) else dst
                shutil.copytree(src, target)
            else:
                shutil.copy2(src, dst)
        except (OSError, shutil.Error) as exc:
            c.e("cp: %s\n" % exc)


def c_mv(c, a):
    flags, paths, _ = _opts(a)
    if len(paths) < 2:
        c.e("mv: missing destination\n")
        return 1
    dst = _resolve(paths[-1])
    for name in paths[:-1]:
        try:
            shutil.move(_resolve(name), dst)
        except (OSError, shutil.Error) as exc:
            c.e("mv: %s\n" % exc)


def c_find(c, a):
    flags, rest, vals = _opts(a, ("-name", "-iname", "-type"))
    root = rest[0] if rest else "."
    pat = vals.get("-name") or vals.get("-iname")
    nocase = "-iname" in vals
    typ = vals.get("-type")
    base = _resolve(root)
    count = 0
    for dp, dn, fn in os.walk(base):
        entries = [(d, True) for d in dn] + [(f, False) for f in fn]
        for name, is_dir in entries:
            if typ == "f" and is_dir or typ == "d" and not is_dir:
                continue
            if pat:
                n1, p1 = (name.lower(), pat.lower()) if nocase else (name, pat)
                if not fnmatch.fnmatch(n1, p1):
                    continue
            full = os.path.join(dp, name)
            c.w(os.path.join(root, os.path.relpath(full, base)) + "\n")
            count += 1
            if count > 2000:
                c.w("... (truncated)\n")
                return


def c_grep(c, a):
    flags, rest, _ = _opts(a)
    if not rest:
        c.e("usage: grep [-inr] pattern [files...]\n")
        return 2
    pattern, files = rest[0], rest[1:] or (["."] if "-r" in flags else [])
    try:
        rx = re.compile(pattern, re.I if "-i" in flags else 0)
    except re.error as exc:
        c.e("grep: bad pattern: %s\n" % exc)
        return 2
    targets = []
    for f in files:
        full = _resolve(f)
        if os.path.isdir(full):
            for dp, dn, fn in os.walk(full):
                dn[:] = [d for d in dn if not d.startswith(".")]
                targets.extend((os.path.join(dp, x), os.path.relpath(os.path.join(dp, x), _state["cwd"])) for x in fn)
        else:
            targets.append((full, f))
    multi = len(targets) > 1
    for full, shown in targets:
        try:
            with open(full, "r", encoding="utf-8", errors="ignore") as fh:
                for i, line in enumerate(fh, 1):
                    if rx.search(line):
                        prefix = (shown + ":") if multi else ""
                        if "-n" in flags:
                            prefix += "%d:" % i
                        c.w(prefix + line.rstrip("\n") + "\n")
        except OSError:
            pass


def c_tree(c, a):
    flags, rest, _ = _opts(a)
    root = _resolve(rest[0] if rest else ".")
    c.w(_color(os.path.basename(root) or "/", "1;34") + "\n")
    state = {"n": 0}

    def walk(path, prefix, depth):
        if depth > 4 or state["n"] > 500:
            return
        try:
            names = sorted(os.listdir(path), key=str.lower)
        except OSError:
            return
        names = [n for n in names if not n.startswith(".") and n != "__pycache__"]
        for i, n in enumerate(names):
            last = i == len(names) - 1
            full = os.path.join(path, n)
            state["n"] += 1
            label = _color(n + "/", "1;34") if os.path.isdir(full) else n
            c.w(prefix + ("\u2514\u2500\u2500 " if last else "\u251c\u2500\u2500 ") + label + "\n")
            if os.path.isdir(full):
                walk(full, prefix + ("    " if last else "\u2502   "), depth + 1)

    walk(root, "", 1)


def _dir_size(p):
    total = 0
    for dp, dn, fn in os.walk(p):
        for f in fn:
            try:
                total += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
    return total


def c_du(c, a):
    flags, rest, _ = _opts(a)
    for name in rest or ["."]:
        p = _resolve(name)
        size = _dir_size(p) if os.path.isdir(p) else (os.path.getsize(p) if os.path.exists(p) else 0)
        c.w("%s\t%s\n" % (_human(size), name))


def c_env(c, a):
    env = dict(os.environ)
    env.update(_state["env"])
    for k in sorted(env):
        c.w("%s=%s\n" % (k, env[k]))


def c_export(c, a):
    for item in a:
        if "=" in item:
            k, v = item.split("=", 1)
            _state["env"][k] = v
            os.environ[k] = v


def c_which(c, a):
    for name in a:
        if name in COMMANDS:
            c.w("%s: shell builtin\n" % name)
        else:
            c.e("%s not found\n" % name)


def c_date(c, a):
    c.w(time.strftime("%a %b %d %H:%M:%S %Z %Y") + "\n")


def c_uname(c, a):
    c.w("Linux %s Android (Python %s)\n" % (platform.machine(), platform.python_version()))


def c_whoami(c, a):
    c.w("pystudio\n")


def c_clear(c, a):
    _sink.onText("term", "clear", "")


def c_edit(c, a):
    if not a:
        c.e("usage: edit <file>\n")
        return 1
    p = _resolve(a[0])
    if not os.path.exists(p):
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, "a").close()
    _sink.onText("term", "open", p)


def _download(url, dest, c):
    req = urllib.request.Request(url, headers={"User-Agent": "PyStudio/%s" % APP_VERSION})
    with urllib.request.urlopen(req, timeout=30) as resp, open(dest, "wb") as fh:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            fh.write(chunk)
            done += len(chunk)
    c.w("Saved %s (%s)\n" % (os.path.relpath(dest, _state["cwd"]), _human(done)))


def _fname_from_url(url):
    name = os.path.basename(url.split("?")[0].rstrip("/")) or "download"
    return name


def c_wget(c, a):
    flags, rest, vals = _opts(a, ("-O",))
    if not rest:
        c.e("usage: wget <url> [-O file]\n")
        return 1
    url = rest[0]
    dest = _resolve(vals.get("-O") or _fname_from_url(url))
    try:
        _download(url, dest, c)
    except Exception as exc:
        c.e("wget: %s\n" % exc)
        return 1


def c_curl(c, a):
    flags, rest, vals = _opts(a, ("-o",))
    if not rest:
        c.e("usage: curl [-o file | -O] <url>\n")
        return 1
    url = rest[0]
    try:
        if "-o" in vals or "-O" in flags:
            _download(url, _resolve(vals.get("-o") or _fname_from_url(url)), c)
        else:
            req = urllib.request.Request(url, headers={"User-Agent": "PyStudio/%s" % APP_VERSION})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read(2_000_000)
            c.w(data.decode("utf-8", errors="replace"))
            if not data.endswith(b"\n"):
                c.w("\n")
    except Exception as exc:
        c.e("curl: %s\n" % exc)
        return 1


def c_unzip(c, a):
    flags, rest, vals = _opts(a, ("-d",))
    if not rest:
        c.e("usage: unzip file.zip [-d dir]\n")
        return 1
    src = _resolve(rest[0])
    dest = _resolve(vals.get("-d", "."))
    try:
        with zipfile.ZipFile(src) as zf:
            for member in zf.namelist():
                target = os.path.normpath(os.path.join(dest, member))
                if not target.startswith(dest):
                    c.e("skipping unsafe path %s\n" % member)
                    continue
                zf.extract(member, dest)
            c.w("Extracted %d files to %s\n" % (len(zf.namelist()), os.path.relpath(dest, _state["cwd"])))
    except (OSError, zipfile.BadZipFile) as exc:
        c.e("unzip: %s\n" % exc)
        return 1


def c_python(c, a):
    if not a:
        return _start_repl(c)
    flags, rest, vals = _opts(a, ("-c", "-m"))
    if "-V" in flags or "--version" in flags:
        c.w("Python %s\n" % platform.python_version())
        return 0
    if "-c" in vals:
        _run_source_in_shell(c, vals["-c"], "<string>", rest)
        return 0
    if "-m" in vals:
        mod = vals["-m"]
        if mod == "pip":
            return pip_main(rest, c)
        src = "import runpy, sys\nrunpy.run_module(%r, run_name='__main__', alter_sys=True)\n" % mod
        _run_source_in_shell(c, src, "<module %s>" % mod, rest)
        return 0
    path = _resolve(rest[0])
    if not os.path.isfile(path):
        c.e("python: can't open file '%s': No such file\n" % rest[0])
        return 2
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        source = fh.read()
    _run_source_in_shell(c, source, path, rest[1:])
    return 0


def _run_source_in_shell(c, source, filename, argv):
    """Execute inside the already-redirected terminal streams."""
    before = _snapshot(_state["cwd"])
    started = time.time()
    _run_images[0] = 0
    old_argv, old_cwd, old_path = sys.argv[:], os.getcwd(), sys.path[:]
    try:
        os.chdir(_state["cwd"])
        sys.path.insert(0, _state["cwd"])
        sys.argv = [filename] + list(argv)
        _ensure_patches(source + "\n" + _sibling_sources(_state["cwd"]))
        glb = {"__name__": "__main__", "__file__": filename, "__builtins__": builtins}
        try:
            exec(compile(source, filename, "exec"), glb)
        except SystemExit as exc:
            if exc.code not in (None, 0):
                sys.stderr.write("Process exited with code %s\n" % (exc.code,))
        except KeyboardInterrupt:
            sys.stderr.write("\nKeyboardInterrupt\n")
        except BaseException:
            _print_exception(sys.exc_info(), filename)
        finally:
            try:
                emit_open_figures(close=True)
            except BaseException:
                pass
        if _run_images[0]:
            _sink.onText("term", "info", "\u2192 %d image(s) shown in the Output tab\n" % _run_images[0])
    finally:
        sys.argv = old_argv
        sys.path[:] = old_path
        try:
            os.chdir(old_cwd)
        except OSError:
            pass


def _start_repl(c):
    ns = {"__name__": "__main__", "__builtins__": builtins}
    console = _code.InteractiveConsole(ns)
    _state["repl"] = {"console": console, "prompt": ">>> "}
    c.w("Python %s (PyStudio)\nType exit() or press the Exit button to leave.\n" % platform.python_version())
    return 0


def _repl_line(c, line):
    repl = _state["repl"]
    if line.strip() in ("exit", "quit", "exit()", "quit()"):
        _state["repl"] = None
        return
    try:
        os.chdir(_state["cwd"])
        _ensure_patches(line)
        more = repl["console"].push(line)
        repl["prompt"] = "... " if more else ">>> "
    except SystemExit:
        _state["repl"] = None
    except KeyboardInterrupt:
        repl["console"].resetbuffer()
        repl["prompt"] = ">>> "
        sys.stderr.write("\nKeyboardInterrupt\n")


COMMANDS = {
    "help": c_help, "pwd": c_pwd, "cd": c_cd, "ls": c_ls, "ll": lambda c, a: c_ls(c, ["-l"] + a),
    "dir": c_ls, "cat": c_cat, "head": c_head, "tail": c_tail, "wc": c_wc, "echo": c_echo,
    "touch": c_touch, "mkdir": c_mkdir, "rmdir": c_rmdir, "rm": c_rm, "cp": c_cp, "mv": c_mv,
    "find": c_find, "grep": c_grep, "tree": c_tree, "du": c_du, "env": c_env, "printenv": c_env,
    "export": c_export, "which": c_which, "date": c_date, "uname": c_uname, "whoami": c_whoami,
    "clear": c_clear, "cls": c_clear, "edit": c_edit, "code": c_edit, "nano": c_edit, "vi": c_edit,
    "vim": c_edit, "wget": c_wget, "curl": c_curl, "unzip": c_unzip,
    "python": c_python, "python3": c_python, "py": c_python,
    "pip": lambda c, a: pip_main(a, c), "pip3": lambda c, a: pip_main(a, c),
}


def _run_command(c, line):
    try:
        tokens = shlex.split(line)
    except ValueError as exc:
        c.e("syntax error: %s\n" % exc)
        return 2
    if not tokens:
        return 0
    redirect = None
    for i, t in enumerate(tokens):
        if t in (">", ">>") and i + 1 < len(tokens):
            redirect = (t, tokens[i + 1])
            tokens = tokens[:i]
            break
    # simple VAR=value prefix assignment
    if tokens and re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", tokens[0]) and len(tokens) == 1:
        c_export(c, tokens)
        return 0
    name, args = tokens[0], tokens[1:]
    fn = COMMANDS.get(name)
    if fn is None:
        if name in ("exit", "logout"):
            c.w("Use the tab bar to leave the terminal.\n")
            return 0
        if name.endswith(".py") and os.path.isfile(_resolve(name)):
            fn = c_python
            args = [name] + args
        else:
            c.e("%s: command not found (type 'help')\n" % name)
            return 127
    if redirect:
        c.capture = []
    try:
        rc = fn(c, args)
    finally:
        if redirect:
            text = "".join(c.capture)
            c.capture = None
            try:
                with open(_resolve(redirect[1]), "a" if redirect[0] == ">>" else "w", encoding="utf-8") as fh:
                    fh.write(text)
            except OSError as exc:
                c.e("%s: %s\n" % (redirect[1], exc.strerror))
    return rc or 0


def shell_exec(line):
    """Run one terminal line (blocking). Reports completion through sink.onDone."""
    started = time.time()
    status = "ok"
    _state["thread_id"] = threading.get_ident()
    with _run_lock:
        try:
            with _redirect("term") as out:
                c = _Ctx(out)
                try:
                    if _state["repl"] is not None:
                        _repl_line(c, line)
                    else:
                        rc = _run_command(c, line)
                        status = "ok" if not rc else "error"
                except KeyboardInterrupt:
                    status = "stopped"
                    out.put("stderr", "^C\n")
                except SystemExit:
                    pass
                except BaseException:
                    status = "error"
                    out.put("stderr", traceback.format_exc())
        finally:
            _state["thread_id"] = None
    _finish("term", status, started, prompt=_prompt())


def shell_prompt():
    return _prompt()


def shell_leave_repl():
    _state["repl"] = None
    return _prompt()


def shell_complete(line):
    """Return completion candidates for the last word of ``line`` as JSON."""
    try:
        parts = line.split(" ")
        last = parts[-1]
        out = []
        if len(parts) == 1 and "/" not in last:
            out = [n for n in sorted(COMMANDS) if n.startswith(last)]
        d, base = os.path.split(last)
        folder = _resolve(d) if d else _state["cwd"]
        if os.path.isdir(folder):
            for n in sorted(os.listdir(folder)):
                if n.startswith(base) and (base or not n.startswith(".")):
                    full = os.path.join(folder, n)
                    out.append((d + "/" if d else "") + n + ("/" if os.path.isdir(full) else ""))
        return json.dumps(out[:50])
    except Exception:
        return "[]"


# ---------------------------------------------------------------------------
# pip (pure-Python wheels from PyPI)
# ---------------------------------------------------------------------------
# Packages built into the APK at build time (see app/build.gradle.kts).
BUNDLED = {
    "numpy": "1.23.3", "scipy": "1.8.1", "pandas": "1.5.0", "matplotlib": "3.6.0",
    "pillow": "9.2.0", "opencv-python-headless": "4.5.1.48", "scikit-learn": "1.3.2",
    "scikit-image": "0.18.3", "packaging": "", "requests": "", "beautifulsoup4": "",
    "lxml": "", "pyyaml": "", "sympy": "", "networkx": "", "imageio": "",
    "seaborn": "", "tqdm": "",
}
ALIASES = {
    "opencv-python": "opencv-python-headless",
    "opencv-contrib-python": "opencv-python-headless",
    "opencv-contrib-python-headless": "opencv-python-headless",
    "pil": "pillow",
    "sklearn": "scikit-learn",
    "skimage": "scikit-image",
    "yaml": "pyyaml",
    "bs4": "beautifulsoup4",
}
NATIVE_HELP = (
    "'%s' contains native (C/C++/Rust) code. Android cannot load native code that is\n"
    "downloaded at runtime, so it must be bundled when the APK is built:\n"
    "  1. open app/build.gradle.kts and add   install(\"%s\")   to the pip { } block\n"
    "  2. upload the project ZIP again - GitHub Actions builds and publishes a new APK.\n"
    "(Chaquopy's native package list: https://chaquo.com/pypi-13.1/)\n"
)


def _norm(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def _site_dists():
    dists = {}
    try:
        for entry in os.listdir(SITE):
            if entry.endswith(".dist-info"):
                stem = entry[: -len(".dist-info")]
                if "-" in stem:
                    name, ver = stem.rsplit("-", 1)
                    dists[_norm(name)] = (ver, os.path.join(SITE, entry))
    except OSError:
        pass
    return dists


def _installed_version(norm):
    """Return (version, source) or None."""
    site = _site_dists()
    if norm in BUNDLED:
        ver = None
        try:
            from importlib import metadata

            ver = metadata.version(norm)
        except Exception:
            ver = BUNDLED[norm] or "?"
        return ver, "bundled"
    if norm in site:
        return site[norm][0], "site"
    try:
        from importlib import metadata

        return metadata.version(norm), "bundled"
    except Exception:
        return None


def _http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "PyStudio/%s" % APP_VERSION, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=25) as resp:
        return json.loads(resp.read().decode("utf-8"))


class _PipError(Exception):
    pass


def _py_ok(requires_python):
    if not requires_python:
        return True
    try:
        from packaging.specifiers import SpecifierSet

        return SpecifierSet(requires_python).contains(platform.python_version(), prereleases=True)
    except Exception:
        return True


def _choose_release(name, spec, allow_pre):
    from packaging.version import Version, InvalidVersion

    try:
        meta = _http_json("https://pypi.org/pypi/%s/json" % name)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise _PipError("No matching distribution found for %s (not on PyPI)" % name)
        raise _PipError("PyPI error %s while looking up %s" % (exc.code, name))
    except Exception as exc:
        raise _PipError("Network error while contacting PyPI: %s" % exc)
    best, seen_native = None, False
    for ver_s, files in meta.get("releases", {}).items():
        try:
            v = Version(ver_s)
        except InvalidVersion:
            continue
        if v.is_prerelease and not allow_pre and not spec.prereleases:
            continue
        if not spec.contains(v, prereleases=True):
            continue
        usable = [f for f in files if not f.get("yanked")]
        if not usable:
            continue
        pure = [f for f in usable if f["filename"].endswith("-none-any.whl") and _py_ok(f.get("requires_python"))]
        if pure:
            if best is None or v > best[0]:
                best = (v, ver_s, pure[0])
        else:
            seen_native = True
    if best is None:
        if seen_native:
            raise _PipError(NATIVE_HELP % (name, name))
        raise _PipError("No matching distribution found for %s%s" % (name, spec if str(spec) else ""))
    return best


def _requires_dist(name, version):
    try:
        data = _http_json("https://pypi.org/pypi/%s/%s/json" % (name, version))
        return data.get("info", {}).get("requires_dist") or []
    except Exception:
        return []


def _download_wheel(entry, c):
    url, fname = entry["url"], entry["filename"]
    cache = os.path.join(HOME, ".pip-cache")
    os.makedirs(cache, exist_ok=True)
    dest = os.path.join(cache, fname)
    req = urllib.request.Request(url, headers={"User-Agent": "PyStudio/%s" % APP_VERSION})
    sha = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=30) as resp, open(dest, "wb") as fh:
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            sha.update(chunk)
            fh.write(chunk)
    expected = (entry.get("digests") or {}).get("sha256")
    if expected and sha.hexdigest() != expected:
        os.remove(dest)
        raise _PipError("Hash mismatch for %s" % fname)
    return dest


def _uninstall_dist(norm):
    site = _site_dists()
    if norm not in site:
        return False
    info_dir = site[norm][1]
    record = os.path.join(info_dir, "RECORD")
    dirs = set()
    try:
        with open(record, "r", encoding="utf-8") as fh:
            for line in fh:
                rel = line.split(",")[0].strip()
                if not rel or rel.startswith(".."):
                    continue
                p = os.path.normpath(os.path.join(SITE, rel))
                if p.startswith(SITE) and os.path.isfile(p):
                    os.remove(p)
                    dirs.add(os.path.dirname(p))
    except OSError:
        pass
    shutil.rmtree(info_dir, ignore_errors=True)
    for d in sorted(dirs, key=len, reverse=True):
        while d.startswith(SITE) and d != SITE:
            try:
                os.rmdir(d)
            except OSError:
                break
            d = os.path.dirname(d)
    return True


def _install_wheel(path):
    """Extract a pure-Python wheel into SITE. Returns (name, version)."""
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        dist_info = next((n.split("/")[0] for n in names if n.split("/")[0].endswith(".dist-info")), None)
        if dist_info is None:
            raise _PipError("%s is not a valid wheel" % os.path.basename(path))
        stem = dist_info[: -len(".dist-info")]
        name, ver = stem.rsplit("-", 1)
        wheel_meta = zf.read(dist_info + "/WHEEL").decode("utf-8", "ignore") if dist_info + "/WHEEL" in names else ""
        if "Root-Is-Purelib: false" in wheel_meta:
            raise _PipError(NATIVE_HELP % (name, name))
        _uninstall_dist(_norm(name))
        for member in names:
            if member.endswith("/"):
                continue
            target_rel = member
            first = member.split("/")[0]
            if first.endswith(".data"):
                parts = member.split("/")
                if len(parts) > 2 and parts[1] in ("purelib", "platlib"):
                    target_rel = "/".join(parts[2:])
                else:
                    continue
            target = os.path.normpath(os.path.join(SITE, target_rel))
            if not target.startswith(SITE):
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with zf.open(member) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
        with open(os.path.join(SITE, dist_info, "INSTALLER"), "w") as fh:
            fh.write("pystudio-pip\n")
    importlib.invalidate_caches()
    return name, ver


def _install_requirement(req_str, c, state, top, upgrade, no_deps, allow_pre):
    from packaging.requirements import Requirement, InvalidRequirement
    from packaging.specifiers import SpecifierSet

    if req_str.lower().endswith(".whl") or os.path.isfile(_resolve(req_str)):
        path = _resolve(req_str)
        if not os.path.isfile(path):
            raise _PipError("Could not open %s" % req_str)
        c.w("Processing %s\n" % os.path.basename(path))
        name, ver = _install_wheel(path)
        state["installed"].append("%s-%s" % (name, ver))
        return
    try:
        req = Requirement(req_str)
    except InvalidRequirement:
        raise _PipError("Invalid requirement: %r" % req_str)
    norm = _norm(req.name)
    if norm in state["seen"]:
        return
    state["seen"].add(norm)
    if req.url:
        raise _PipError("Installing from URLs/VCS is not supported (%s)" % req_str)
    spec = req.specifier
    alias = ALIASES.get(norm)
    if alias:
        c.w("Requirement already satisfied: %s (provided by bundled %s)\n" % (req.name, alias))
        if "contrib" in norm:
            c.w("  note: opencv-contrib extra modules are not available in the bundled build\n")
        return
    have = _installed_version(norm)
    if have is not None:
        ver, source = have
        ok = ((not spec) or spec.contains(ver, prereleases=True)) if ver and ver != "?" else True
        if source == "bundled":
            if ok:
                c.w("Requirement already satisfied: %s%s (bundled with the app)\n" % (norm, "" if ver == "?" else "==" + ver))
                return
            raise _PipError(
                "%s %s is bundled with the app and cannot be changed at runtime (requested %s).\n"
                "Edit the version in app/build.gradle.kts and rebuild to change it." % (norm, ver, spec)
            )
        if ok and not (top and upgrade):
            c.w("Requirement already satisfied: %s==%s (in site-packages)\n" % (norm, ver))
            return
    c.w("Collecting %s%s\n" % (req.name, spec if str(spec) else ""))
    ver_obj, ver_s, entry = _choose_release(req.name, spec, allow_pre)
    size_kb = max(1, int(entry.get("size", 0) / 1024))
    c.w("  Downloading %s (%d kB)\n" % (entry["filename"], size_kb))
    deps = [] if no_deps else _requires_dist(req.name, ver_s)
    path = _download_wheel(entry, c)
    name, ver = _install_wheel(path)
    state["installed"].append("%s-%s" % (name, ver))
    for dep in deps:
        try:
            d = Requirement(dep)
        except InvalidRequirement:
            continue
        if d.marker is not None:
            try:
                if not d.marker.evaluate({"extra": ""}):
                    continue
            except Exception:
                continue
        _install_requirement(str(d).split(";")[0], c, state, False, False, no_deps, allow_pre)


def _pip_install(args, c):
    flags, rest, vals = _opts(args, ("-r", "--requirement", "-i", "--index-url", "--target", "-t"))
    reqs = list(rest)
    rfile = vals.get("-r") or vals.get("--requirement")
    if rfile:
        text = _read_text(c, rfile)
        if text is None:
            return 1
        for line in text.splitlines():
            line = line.split("#")[0].strip()
            if line and not line.startswith("-"):
                reqs.append(line)
    if not reqs:
        c.e("ERROR: You must give at least one requirement to install\n")
        return 1
    if "-i" in vals or "--index-url" in vals:
        c.w("note: custom index URLs are ignored; using PyPI\n")
    try:
        import packaging  # noqa: F401
    except ImportError:
        c.e("ERROR: 'packaging' is missing from this build\n")
        return 1
    state = {"seen": set(), "installed": []}
    upgrade = bool({"-U", "--upgrade", "--force-reinstall"} & flags)
    no_deps = "--no-deps" in flags
    allow_pre = "--pre" in flags
    failed = False
    for r in reqs:
        try:
            _install_requirement(r, c, state, True, upgrade, no_deps, allow_pre)
        except _PipError as exc:
            c.e("ERROR: %s\n" % exc)
            failed = True
        except urllib.error.URLError as exc:
            c.e("ERROR: network error: %s\n" % exc)
            failed = True
    if state["installed"]:
        c.w("Successfully installed %s\n" % " ".join(state["installed"]))
    return 1 if failed else 0


def _pip_uninstall(args, c):
    flags, rest, _ = _opts(args)
    for name in rest:
        norm = _norm(name)
        if norm in BUNDLED or norm in ALIASES:
            c.e("WARNING: %s is bundled with the app and cannot be uninstalled\n" % name)
        elif _uninstall_dist(norm):
            c.w("Successfully uninstalled %s\n" % name)
        else:
            c.e("WARNING: Skipping %s as it is not installed.\n" % name)
    return 0


def _all_packages():
    rows = {}
    for norm in BUNDLED:
        have = _installed_version(norm)
        rows[norm] = (have[0] if have else (BUNDLED[norm] or "?"), "bundled")
    for norm, (ver, _) in _site_dists().items():
        if norm not in rows:
            rows[norm] = (ver, "installed")
    return rows


def pip_list_json():
    rows = _all_packages()
    return json.dumps([{"name": n, "version": v, "source": s} for n, (v, s) in sorted(rows.items())])


def _pip_list(args, c):
    rows = _all_packages()
    c.w("%-28s %-12s %s\n" % ("Package", "Version", "Source"))
    c.w("%s %s %s\n" % ("-" * 28, "-" * 12, "-" * 9))
    for n, (v, s) in sorted(rows.items()):
        c.w("%-28s %-12s %s\n" % (n, v, s))
    return 0


def _pip_show(args, c):
    for name in args:
        norm = ALIASES.get(_norm(name), _norm(name))
        have = _installed_version(norm)
        if not have:
            c.e("WARNING: Package(s) not found: %s\n" % name)
            continue
        c.w("Name: %s\nVersion: %s\nSource: %s\n" % (norm, have[0], have[1]))
        site = _site_dists()
        if norm in site:
            meta = os.path.join(site[norm][1], "METADATA")
            try:
                with open(meta, "r", encoding="utf-8", errors="ignore") as fh:
                    for line in fh:
                        if line.startswith(("Summary:", "Home-page:", "Requires-Dist:")):
                            c.w(line)
                        if not line.strip():
                            break
            except OSError:
                pass
            c.w("Location: %s\n" % SITE)
        c.w("\n")
    return 0


def pip_main(args, c):
    args = list(args)
    if not args or args[0] in ("-h", "--help", "help"):
        c.w("Usage: pip <command> [options]\n\nCommands:\n  install     Install pure-Python packages from PyPI\n"
            "  uninstall   Remove a package installed with pip\n  list        List bundled and installed packages\n"
            "  show        Show package information\n  freeze      Output installed packages\n\n"
            "Native libraries (numpy, opencv, ...) are bundled into the APK at build time.\n")
        return 0
    cmd, rest = args[0], args[1:]
    if cmd in ("--version", "-V", "version"):
        c.w("pip (PyStudio runtime) from %s (python %s)\n" % (SITE, platform.python_version()))
        return 0
    if cmd == "install":
        return _pip_install(rest, c)
    if cmd == "uninstall":
        return _pip_uninstall(rest, c)
    if cmd == "list":
        return _pip_list(rest, c)
    if cmd == "show":
        return _pip_show(rest, c)
    if cmd == "freeze":
        for n, (v, s) in sorted(_all_packages().items()):
            c.w("%s==%s\n" % (n, v))
        return 0
    c.e("ERROR: unknown command %r (try: install, uninstall, list, show, freeze)\n" % cmd)
    return 1

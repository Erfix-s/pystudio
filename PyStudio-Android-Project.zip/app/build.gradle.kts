plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

// ---------------------------------------------------------------------------
// Versioning
// The CI workflow exports PYSTUDIO_RUN_NUMBER (the GitHub run number), which is
// strictly increasing, so every build gets a higher versionCode and a new
// versionName and installs directly over the previous one.
// ---------------------------------------------------------------------------
val runNumber: Int = (System.getenv("PYSTUDIO_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1

android {
    namespace = "com.pystudio.app"
    compileSdk = 35

    defaultConfig {
        // NEVER change this id: it is what lets new builds update old installs.
        applicationId = "com.pystudio.app"
        minSdk = 24
        targetSdk = 34
        versionCode = runNumber
        versionName = "1.0.$runNumber"

        ndk {
            // Python 3.10 wheels with native code are bundled for 64-bit phones.
            abiFilters += listOf("arm64-v8a")
        }
    }

    // One fixed keystore, stored in the project, signs every build.
    signingConfigs {
        create("pystudio") {
            storeFile = file("pystudio-release.keystore")
            storePassword = "pystudio-release"
            keyAlias = "pystudio"
            keyPassword = "pystudio-release"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("pystudio")
        }
        debug {
            signingConfig = signingConfigs.getByName("pystudio")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

chaquopy {
    defaultConfig {
        version = "3.10"

        pip {
            // ---- Scientific stack (native code, built for Android by Chaquopy) ----
            install("numpy==1.23.3")
            install("scipy==1.8.1")
            install("pandas==1.5.0")
            install("matplotlib==3.6.0")
            install("pillow==9.2.0")
            install("opencv-python-headless==4.5.1.48")
            install("scikit-learn==1.3.2")
            install("scikit-image==0.18.3")

            // ---- Popular pure-Python libraries ----
            install("packaging")
            install("requests")
            install("beautifulsoup4")
            install("lxml")
            install("pyyaml")
            install("sympy")
            install("networkx")
            install("imageio")
            install("seaborn")
            install("tqdm")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}

"""PyStudio runtime.

Executes a user's Python source on Chaquopy while streaming stdout/stderr and
images back to the Android UI. matplotlib is forced to the Agg backend; show(),
cv2.imshow() and PIL Image.show() are redirected to PNG files that the Output
tab renders. This is how GUI-only APIs are adapted to a phone screen.
"""

import builtins
import io
import os
import sys
import time
import traceback

_bridge = None
_out_dir = None
_counter = 0
_matplotlib_plt = None
_cv2 = None
_pil_image = None
_prepared_for = set()


class _OutputStream(io.TextIOBase):
    def __init__(self, bridge, is_error=False):
        self._bridge = bridge
        self._is_error = is_error

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        if text:
            if self._is_error:
                self._bridge.error(text)
            else:
                self._bridge.text(text)
        return len(text)

    def flush(self):
        return None

    def isatty(self):
        return False

    def writable(self):
        return True

    @property
    def encoding(self):
        return "utf-8"


class _NoStdin(io.TextIOBase):
    def readable(self):
        return True

    def read(self, size=-1):
        return ""

    def readline(self, size=-1):
        raise EOFError(
            "Interactive input() is disabled in PyStudio. "
            "Set values in the code or use the terminal for commands."
        )

    def isatty(self):
        return False


def _next_image_path(label):
    global _counter
    _counter += 1
    safe_label = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(label))[:36]
    filename = "img_%04d_%s.png" % (_counter, safe_label or "output")
    return os.path.join(_out_dir, filename)


def _emit_image(path):
    try:
        _bridge.image(path)
    except Exception:
        pass


def _install_matplotlib():
    global _matplotlib_plt
    if _matplotlib_plt is not None:
        return _matplotlib_plt
    try:
        os.environ["MPLBACKEND"] = "Agg"
        import matplotlib
        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt

        def _show(*args, **kwargs):
            for number in plt.get_fignums():
                figure = plt.figure(number)
                path = _next_image_path("matplotlib_%s" % number)
                try:
                    figure.savefig(
                        path,
                        dpi=150,
                        bbox_inches="tight",
                        facecolor=figure.get_facecolor(),
                    )
                    _emit_image(path)
                except Exception as error:
                    _bridge.error("PyStudio: could not render figure: %r\n" % error)
            plt.close("all")

        _show._pystudio = True
        plt.show = _show
        _matplotlib_plt = plt
        return plt
    except Exception as error:
        _bridge.error("PyStudio: matplotlib is unavailable: %r\n" % error)
        return None


def _install_cv2():
    global _cv2
    if _cv2 is not None:
        return _cv2
    try:
        import cv2

        def _imshow(window_name, image):
            try:
                path = _next_image_path("cv2_%s" % window_name)
                if not cv2.imwrite(path, image):
                    raise RuntimeError("cv2.imwrite returned False")
                _emit_image(path)
            except Exception as error:
                _bridge.error("PyStudio: could not render cv2 image: %r\n" % error)

        cv2.imshow = _imshow
        cv2.waitKey = lambda *args, **kwargs: -1
        cv2.waitKeyEx = lambda *args, **kwargs: -1
        cv2.destroyAllWindows = lambda *args, **kwargs: None
        cv2.destroyWindow = lambda *args, **kwargs: None
        cv2.namedWindow = lambda *args, **kwargs: None
        _cv2 = cv2
        return cv2
    except Exception as error:
        _bridge.error("PyStudio: OpenCV is unavailable: %r\n" % error)
        return None


def _install_pillow():
    global _pil_image
    if _pil_image is not None:
        return _pil_image
    try:
        from PIL import Image

        def _show(self, *args, **kwargs):
            try:
                path = _next_image_path("pil_image")
                self.save(path, format="PNG")
                _emit_image(path)
            except Exception as error:
                _bridge.error("PyStudio: could not render PIL image: %r\n" % error)

        Image.Image.show = _show
        _pil_image = Image
        return Image
    except Exception as error:
        _bridge.error("PyStudio: Pillow is unavailable: %r\n" % error)
        return None


def _prepare(source):
    lowered = source.lower()
    if ("matplotlib" in lowered or "plt." in lowered) and "matplotlib" not in _prepared_for:
        _install_matplotlib()
        _prepared_for.add("matplotlib")
    if ("cv2" in lowered or "opencv" in lowered) and "cv2" not in _prepared_for:
        _install_cv2()
        _prepared_for.add("cv2")
    if ("pil" in lowered or "pillow" in lowered or "image.open" in lowered) and "pil" not in _prepared_for:
        _install_pillow()
        _prepared_for.add("pil")


def _flush_figures():
    if _matplotlib_plt is None:
        return
    try:
        for number in _matplotlib_plt.get_fignums():
            figure = _matplotlib_plt.figure(number)
            path = _next_image_path("figure_%s" % number)
            figure.savefig(path, dpi=150, bbox_inches="tight", facecolor=figure.get_facecolor())
            _emit_image(path)
        _matplotlib_plt.close("all")
    except Exception:
        pass


def run(code, filename, workspace, bridge):
    """Entry point called from Java/PythonEngine."""
    global _bridge, _out_dir

    _bridge = bridge
    workspace = os.path.abspath(workspace)
    os.makedirs(workspace, exist_ok=True)
    _out_dir = os.path.join(workspace, ".pystudio", "images")
    os.makedirs(_out_dir, exist_ok=True)
    # The Output tab is cleared at the start of every run, so old rendered
    # PNGs are no longer referenced. Keep the private cache from growing.
    try:
        now = time.time()
        for name in os.listdir(_out_dir):
            if not name.lower().endswith(".png"):
                continue
            path = os.path.join(_out_dir, name)
            try:
                if now - os.path.getmtime(path) > 86400:
                    os.unlink(path)
            except OSError:
                pass
    except OSError:
        pass

    previous_cwd = None
    previous_stdout = sys.stdout
    previous_stderr = sys.stderr
    previous_stdin = sys.stdin
    success = False
    started = time.time()

    try:
        previous_cwd = os.getcwd()
    except Exception:
        pass

    try:
        os.chdir(workspace)
        os.environ["HOME"] = workspace
        os.environ["PYSTUDIO_HOME"] = workspace
        if workspace not in sys.path:
            sys.path.insert(0, workspace)
        sys.stdout = _OutputStream(bridge, False)
        sys.stderr = _OutputStream(bridge, True)
        sys.stdin = _NoStdin()

        _prepare(code)
        script_path = os.path.join(workspace, filename if filename else "main.py")
        globals_dict = {
            "__name__": "__main__",
            "__file__": script_path,
            "__package__": None,
            "__builtins__": builtins,
        }
        compiled = compile(code, filename or "main.py", "exec")
        sys.argv = [filename or "main.py"]
        exec(compiled, globals_dict, globals_dict)
        _flush_figures()
        success = True
    except SystemExit as exit_error:
        code_value = exit_error.code
        if code_value not in (None, 0):
            _bridge.error("SystemExit: %s\n" % code_value)
        else:
            success = True
    except KeyboardInterrupt:
        _bridge.error("KeyboardInterrupt\n")
    except BaseException:
        _bridge.error(traceback.format_exc())
    finally:
        try:
            _flush_figures()
        except Exception:
            pass
        sys.stdout = previous_stdout
        sys.stderr = previous_stderr
        sys.stdin = previous_stdin
        if previous_cwd:
            try:
                os.chdir(previous_cwd)
            except Exception:
                pass
        try:
            sys.stdout.write("")
        except Exception:
            pass

    return success

package com.pystudio.ide;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * All user code lives in the app's private files directory. Keeping the
 * workspace private means no storage permission is needed and Python can use
 * real filesystem paths (OpenCV cannot read content:// URIs).
 */
public final class Workspace {

    public static final String RUN_DIR = ".pystudio";
    public static final String IMAGE_DIR = ".pystudio/images";

    private Workspace() {
    }

    public static File root(Context context) {
        File dir = new File(context.getFilesDir(), "workspace");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return dir;
    }

    public static File importsDir(Context context) {
        File dir = new File(context.getFilesDir(), "imports");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return dir;
    }

    public static File imageDir(Context context) {
        File dir = new File(root(context), IMAGE_DIR);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return dir;
    }

    public static List<File> listFiles(Context context) {
        File[] files = root(context).listFiles();
        List<File> result = new ArrayList<>();
        if (files != null) {
            for (File file : files) {
                if (!file.isHidden()) {
                    result.add(file);
                }
            }
        }
        result.sort(Comparator
                .comparing((File f) -> !f.isDirectory())
                .thenComparing(f -> f.getName().toLowerCase(Locale.ROOT)));
        return result;
    }

    public static String read(File file) throws IOException {
        byte[] data = java.nio.file.Files.readAllBytes(file.toPath());
        return new String(data, StandardCharsets.UTF_8);
    }

    public static void write(File file, String text) throws IOException {
        File parent = file.getParentFile();
        if (parent != null) {
            //noinspection ResultOfMethodCallIgnored
            parent.mkdirs();
        }
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
    }

    public static File uniqueFile(File directory, String requestedName) {
        String name = sanitizeName(requestedName);
        File candidate = new File(directory, name);
        if (!candidate.exists()) {
            return candidate;
        }
        String base = name;
        String extension = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            extension = name.substring(dot);
        }
        for (int i = 2; i < 1000; i++) {
            candidate = new File(directory, base + " (" + i + ")" + extension);
            if (!candidate.exists()) {
                return candidate;
            }
        }
        return new File(directory, System.currentTimeMillis() + "-" + name);
    }

    public static String sanitizeName(String requestedName) {
        String name = requestedName == null ? "" : requestedName.trim();
        if (name.isEmpty()) {
            name = "untitled.py";
        }
        name = name.replace('/', '_').replace('\\', '_').replace('\u0000', '_');
        if (name.startsWith(".")) {
            name = "file" + name;
        }
        return name;
    }

    /**
     * Resolves a user supplied path while never escaping the workspace.
     */
    public static File resolveInside(File base, String rawPath) {
        try {
            File root = base.getCanonicalFile();
            File target = new File(rawPath);
            if (!target.isAbsolute()) {
                target = new File(root, rawPath);
            }
            File canonical = target.getCanonicalFile();
            String rootPath = root.getPath();
            String targetPath = canonical.getPath();
            if (targetPath.equals(rootPath) || targetPath.startsWith(rootPath + File.separator)) {
                return canonical;
            }
        } catch (IOException ignored) {
        }
        return null;
    }

    public static String formatSize(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        if (bytes < 1024 * 1024) {
            return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        }
        return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    public static String formatDate(long modified) {
        return new SimpleDateFormat("d MMM, HH:mm", Locale.US).format(new Date(modified));
    }

    public static void ensureSeeded(Context context) {
        File root = root(context);
        File marker = new File(root, RUN_DIR + "/.seeded");
        if (marker.exists()) {
            return;
        }
        try {
            write(new File(root, "hello.py"), STARTER_HELLO);
            write(new File(root, "plot_demo.py"), STARTER_PLOT);
            write(new File(root, "opencv_demo.py"), STARTER_CV2);
            write(new File(root, "numpy_demo.py"), STARTER_NUMPY);
            writeSampleImage(new File(root, "sample.png"));
            write(marker, "PyStudio samples created\n");
        } catch (IOException ignored) {
        }
    }

    public static final String[] PACKAGE_SUMMARY = {
            "numpy", "opencv-python", "matplotlib", "pillow", "requests", "beautifulsoup4"
    };

    public static final String PACKAGES_TEXT =
            "numpy 1.26.2\nopencv-python 4.5.1.48\nmatplotlib 3.6.0\nPillow 11.0.0\nrequests\nbeautifulsoup4";

    private static void writeSampleImage(File file) throws IOException {
        if (file.exists()) {
            return;
        }
        int width = 720;
        int height = 440;
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setShader(new LinearGradient(0, 0, width, height,
                new int[]{Color.rgb(7, 17, 12), Color.rgb(11, 60, 45), Color.rgb(120, 170, 30)},
                new float[]{0f, 0.56f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, width, height, paint);

        paint.setShader(null);
        paint.setColor(Color.argb(38, 255, 255, 255));
        for (int i = 0; i < 12; i++) {
            canvas.drawCircle(80 + i * 57, 90 + (i % 3) * 70, 18 + i * 2, paint);
        }
        paint.setColor(Color.rgb(185, 242, 39));
        canvas.drawRect(54, 300, 668, 306, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(46f);
        paint.setFakeBoldText(true);
        canvas.drawText("PyStudio", 54, 280, paint);
        paint.setColor(Color.rgb(204, 231, 216));
        paint.setTextSize(21f);
        paint.setFakeBoldText(false);
        canvas.drawText("sample.png  ·  edit this file with Python", 54, 348, paint);
        paint.setColor(Color.rgb(94, 234, 212));
        canvas.drawCircle(620, 380, 14, paint);

        File parent = file.getParentFile();
        if (parent != null) {
            //noinspection ResultOfMethodCallIgnored
            parent.mkdirs();
        }
        try (FileOutputStream out = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        } finally {
            bitmap.recycle();
        }
    }

    private static final String STARTER_HELLO =
            "# PyStudio · on-device Python\n"
                    + "# Everything in this file runs entirely on your phone.\n"
                    + "import sys\n"
                    + "import platform\n"
                    + "\n"
                    + "print('Hello from PyStudio!')\n"
                    + "print('Python', sys.version.split()[0])\n"
                    + "print('Platform', platform.machine())\n"
                    + "\n"
                    + "for n in range(1, 6):\n"
                    + "    print('  ' + '★' * n)\n"
                    + "\n"
                    + "print('\\nTip: open the files tab to try NumPy, OpenCV or Matplotlib.')\n";

    private static final String STARTER_PLOT =
            "import matplotlib.pyplot as plt\n"
                    + "import numpy as np\n"
                    + "\n"
                    + "x = np.linspace(0, 2 * np.pi, 240)\n"
                    + "y = np.sin(x)\n"
                    + "\n"
                    + "plt.figure(figsize=(7, 4))\n"
                    + "plt.plot(x, y, color='#2bb673', linewidth=2.4, label='sin(x)')\n"
                    + "plt.plot(x, np.cos(x), color='#4a90d9', linestyle='--', label='cos(x)')\n"
                    + "plt.title('PyStudio · rendered on Android')\n"
                    + "plt.xlabel('radians')\n"
                    + "plt.grid(alpha=0.25)\n"
                    + "plt.legend()\n"
                    + "\n"
                    + "# plt.show() is captured and displayed in the Output tab.\n"
                    + "plt.show()\n";

    private static final String STARTER_CV2 =
            "import cv2\n"
                    + "import numpy as np\n"
                    + "\n"
                    + "# sample.png was created in your workspace on first launch.\n"
                    + "# Use the Path button in the editor to pick any phone file.\n"
                    + "image = cv2.imread('sample.png')\n"
                    + "\n"
                    + "if image is None:\n"
                    + "    print('Could not read sample.png')\n"
                    + "else:\n"
                    + "    print('shape:', image.shape)\n"
                    + "    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)\n"
                    + "    edges = cv2.Canny(gray, 70, 160)\n"
                    + "    print('edge pixels:', int(np.count_nonzero(edges)))\n"
                    + "    # cv2.imshow is emulated: the image appears in the Output tab.\n"
                    + "    cv2.imshow('original', image)\n"
                    + "    cv2.imshow('edges', edges)\n"
                    + "    cv2.waitKey(0)\n"
                    + "    cv2.destroyAllWindows()\n";

    private static final String STARTER_NUMPY =
            "import numpy as np\n"
                    + "\n"
                    + "matrix = np.array([[3, 1, 4], [1, 5, 9], [2, 6, 5]])\n"
                    + "print(matrix)\n"
                    + "print('mean  :', matrix.mean())\n"
                    + "print('inverse:')\n"
                    + "print(np.linalg.inv(matrix).round(3))\n"
                    + "print('eigenvalues:', np.linalg.eigvals(matrix).round(3))\n";
}

package com.pystudio.ide;

import android.content.Context;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * A small, deliberately honest shell. It is not a Unix process: commands are
 * interpreted inside the app sandbox so they work without root. pip install can
 * only confirm packages that were bundled at build time, because the APK's
 * Chaquopy environment is immutable at runtime.
 */
public final class TerminalSession {

    public static final class Result {
        public String output = "";
        public boolean error;
        public boolean clear;
        public boolean launchPython;
        public File pythonFile;

        static Result text(String output) {
            Result result = new Result();
            result.output = output;
            return result;
        }

        static Result error(String output) {
            Result result = new Result();
            result.output = output;
            result.error = true;
            return result;
        }
    }

    private final Context context;
    private File cwd;

    public TerminalSession(Context context) {
        this.context = context.getApplicationContext();
        this.cwd = Workspace.root(this.context);
        Workspace.ensureSeeded(this.context);
    }

    public File getCwd() {
        return cwd;
    }

    public String getDisplayPath() {
        File root = Workspace.root(context);
        String rootPath = root.getAbsolutePath();
        String path = cwd.getAbsolutePath();
        if (path.equals(rootPath)) {
            return "~";
        }
        if (path.startsWith(rootPath)) {
            return "~" + path.substring(rootPath.length());
        }
        return path;
    }

    public Result execute(String rawCommand) {
        String line = rawCommand == null ? "" : rawCommand.trim();
        if (line.isEmpty()) {
            return Result.text("");
        }
        List<String> tokens = tokenize(line);
        if (tokens.isEmpty()) {
            return Result.text("");
        }
        String command = tokens.get(0);
        List<String> args = tokens.subList(1, tokens.size());

        switch (command) {
            case "help":
                return Result.text(HELP);
            case "clear":
            case "cls": {
                Result result = new Result();
                result.clear = true;
                return result;
            }
            case "pwd":
                return Result.text(cwd.getAbsolutePath() + "\n");
            case "whoami":
                return Result.text("pystudio\n");
            case "uname":
                return Result.text("Android/Linux " + System.getProperty("os.arch")
                        + " (app sandbox, Bionic libc)\n");
            case "date":
                return Result.text(new SimpleDateFormat("EEE dd MMM yyyy HH:mm:ss z", Locale.US).format(new Date()) + "\n");
            case "echo":
                return Result.text(String.join(" ", args) + "\n");
            case "ls":
                return list(args);
            case "cd":
                return changeDirectory(args);
            case "cat":
                return cat(args);
            case "mkdir":
                return mkdir(args);
            case "touch":
                return touch(args);
            case "rm":
                return remove(args);
            case "python":
            case "python3":
                return python(args);
            case "pip":
            case "pip3":
                return pip(args);
            case "run":
                return runFile(args);
            default:
                return Result.error(command + ": command not found\nType 'help' to see the supported commands.\n");
        }
    }

    private Result list(List<String> args) {
        File directory = args.isEmpty() ? cwd : resolve(args.get(0));
        if (directory == null) {
            return Result.error("ls: cannot access '" + args.get(0) + "': outside the workspace\n");
        }
        if (!directory.exists()) {
            return Result.error("ls: " + args.get(0) + ": No such file or directory\n");
        }
        if (!directory.isDirectory()) {
            return Result.text(directory.getName() + "\n");
        }
        File[] children = directory.listFiles();
        if (children == null || children.length == 0) {
            return Result.text("(empty)\n");
        }
        Arrays.sort(children, (a, b) -> {
            if (a.isDirectory() != b.isDirectory()) {
                return a.isDirectory() ? -1 : 1;
            }
            return a.getName().compareToIgnoreCase(b.getName());
        });
        StringBuilder builder = new StringBuilder();
        for (File child : children) {
            if (child.getName().startsWith(".") && !child.isDirectory()) {
                continue;
            }
            builder.append(child.isDirectory() ? "d  " : "-  ");
            builder.append(child.getName());
            if (child.isDirectory()) {
                builder.append('/');
            } else {
                builder.append("    ").append(Workspace.formatSize(child.length()));
            }
            builder.append('\n');
        }
        return Result.text(builder.toString());
    }

    private Result changeDirectory(List<String> args) {
        if (args.isEmpty()) {
            cwd = Workspace.root(context);
            return Result.text("");
        }
        File target = resolve(args.get(0));
        if (target == null) {
            return Result.error("cd: access outside the workspace is blocked\n");
        }
        if (!target.isDirectory()) {
            return Result.error("cd: " + args.get(0) + ": Not a directory\n");
        }
        cwd = target;
        return Result.text("");
    }

    private Result cat(List<String> args) {
        if (args.isEmpty()) {
            return Result.error("usage: cat <file>\n");
        }
        File file = resolve(args.get(0));
        if (file == null || !file.isFile()) {
            return Result.error("cat: " + args.get(0) + ": No such file\n");
        }
        try {
            String content = Workspace.read(file);
            return Result.text(content.endsWith("\n") ? content : content + "\n");
        } catch (Exception error) {
            return Result.error("cat: " + error.getMessage() + "\n");
        }
    }

    private Result mkdir(List<String> args) {
        if (args.isEmpty()) {
            return Result.error("usage: mkdir <directory>\n");
        }
        File target = resolve(args.get(0));
        if (target == null) {
            return Result.error("mkdir: invalid path\n");
        }
        if (target.exists()) {
            return Result.error("mkdir: " + args.get(0) + ": already exists\n");
        }
        return target.mkdirs() ? Result.text("") : Result.error("mkdir: could not create directory\n");
    }

    private Result touch(List<String> args) {
        if (args.isEmpty()) {
            return Result.error("usage: touch <file>\n");
        }
        File target = resolve(args.get(0));
        if (target == null) {
            return Result.error("touch: invalid path\n");
        }
        try {
            if (!target.exists()) {
                Workspace.write(target, "");
            } else if (!target.setLastModified(System.currentTimeMillis())) {
                return Result.error("touch: could not update file\n");
            }
            return Result.text("");
        } catch (Exception error) {
            return Result.error("touch: " + error.getMessage() + "\n");
        }
    }

    private Result remove(List<String> args) {
        List<String> paths = new ArrayList<>();
        boolean recursive = false;
        for (String arg : args) {
            if (arg.equals("-r") || arg.equals("-rf") || arg.equals("-R")) {
                recursive = true;
            } else {
                paths.add(arg);
            }
        }
        if (paths.isEmpty()) {
            return Result.error("usage: rm [-r] <path>\n");
        }
        File target = resolve(paths.get(0));
        if (target == null || target.equals(Workspace.root(context))) {
            return Result.error("rm: refusing to remove this path\n");
        }
        if (target.isDirectory() && !recursive) {
            return Result.error("rm: " + paths.get(0) + ": is a directory (use rm -r)\n");
        }
        return deleteRecursively(target) ? Result.text("") : Result.error("rm: could not remove " + paths.get(0) + "\n");
    }

    private boolean deleteRecursively(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    if (!deleteRecursively(child)) {
                        return false;
                    }
                }
            }
        }
        return file.delete();
    }

    private Result python(List<String> args) {
        if (args.isEmpty()) {
            return Result.text("CPython 3.10 (Chaquopy)\nInteractive REPL is not available in a script-only embedded interpreter.\n"
                    + "Use: python <file.py>\n");
        }
        if (args.get(0).equals("--version") || args.get(0).equals("-V")) {
            return Result.text("Python 3.10.0 (Chaquopy embedded runtime)\n");
        }
        return runFile(args);
    }

    private Result runFile(List<String> args) {
        if (args.isEmpty()) {
            return Result.error("usage: run <file.py>\n");
        }
        File file = resolve(args.get(0));
        if (file == null || !file.isFile()) {
            return Result.error("python: " + args.get(0) + ": No such file\n");
        }
        if (!file.getName().endsWith(".py")) {
            return Result.error("python: only .py scripts can be executed\n");
        }
        cwd = file.getParentFile() == null ? cwd : file.getParentFile();
        Result result = new Result();
        result.launchPython = true;
        result.pythonFile = file;
        return result;
    }

    private Result pip(List<String> args) {
        if (args.isEmpty() || args.get(0).equals("list") || args.get(0).equals("freeze")) {
            return Result.text("Bundled into this APK:\n\n" + Workspace.PACKAGES_TEXT + "\n");
        }
        String sub = args.get(0);
        if (sub.equals("install")) {
            if (args.size() < 2) {
                return Result.error("ERROR: You must give at least one requirement to install.\n");
            }
            String requested = args.get(args.size() - 1);
            String normalized = requested.toLowerCase(Locale.ROOT).replace("_", "-");
            boolean bundled = false;
            for (String known : new String[]{"numpy", "opencv-python", "opencv-contrib-python", "matplotlib", "pillow", "requests", "beautifulsoup4", "bs4"}) {
                String key = normalized.split("[=<>~]")[0];
                if (key.equals(known)) {
                    bundled = true;
                    break;
                }
            }
            if (bundled) {
                return Result.text("Requirement already satisfied: " + requested + "\n"
                        + "This library is compiled into the APK and importable offline. Use a plain import in your code.\n");
            }
            return Result.error("PyStudio uses a build-time package environment (Chaquopy).\n"
                    + "The APK is immutable, so runtime pip installs are not supported on Android.\n\n"
                    + "To add '" + requested + "': open app/build.gradle, add\n"
                    + "    install \"" + requested + "\"\n"
                    + "inside chaquopy { defaultConfig { pip { ... } } }, commit the ZIP and let\n"
                    + "GitHub Actions build a new APK. Pure-Python packages usually work this way.\n");
        }
        if (sub.equals("uninstall")) {
            return Result.error("pip uninstall is disabled: packages are baked into the signed APK.\n");
        }
        if (sub.equals("--version") || sub.equals("-V")) {
            return Result.text("pip 25.3 (Chaquopy)\n");
        }
        return Result.error("pip: unsupported subcommand '" + sub + "'\nTry: pip list · pip install <package>\n");
    }

    private File resolve(String path) {
        String cleaned = path;
        if (cleaned.equals("~")) {
            return Workspace.root(context);
        }
        if (cleaned.startsWith("~/")) {
            cleaned = cleaned.substring(2);
        }
        File target = new File(cleaned);
        if (!target.isAbsolute()) {
            target = new File(cwd, cleaned);
        }
        return Workspace.resolveInside(Workspace.root(context), target.getAbsolutePath());
    }

    private static List<String> tokenize(String line) {
        List<String> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean single = false;
        boolean doubles = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '\'' && !doubles) {
                single = !single;
                continue;
            }
            if (c == '"' && !single) {
                doubles = !doubles;
                continue;
            }
            if (Character.isWhitespace(c) && !single && !doubles) {
                if (current.length() > 0) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
                continue;
            }
            if (c == '\\' && i + 1 < line.length()) {
                current.append(line.charAt(++i));
                continue;
            }
            current.append(c);
        }
        if (current.length() > 0) {
            tokens.add(current.toString());
        }
        return tokens;
    }

    private static final String HELP =
            "PyStudio shell · all commands run offline in the app sandbox\n\n"
                    + "  ls [dir]            list files\n"
                    + "  cd <dir>            change directory (~ is the workspace)\n"
                    + "  pwd                 print working directory\n"
                    + "  cat <file>          show a file\n"
                    + "  mkdir <dir>         create a directory\n"
                    + "  touch <file>        create an empty file\n"
                    + "  rm [-r] <path>      remove a file or directory\n"
                    + "  python <file.py>    execute a script (streams into this tab)\n"
                    + "  run <file.py>       same as python <file.py>\n"
                    + "  pip list            list libraries bundled at build time\n"
                    + "  pip install <pkg>   explain how to add a native library\n"
                    + "  echo · date · uname · whoami · clear · help\n\n"
                    + "This is an embedded command interpreter, not a full Linux shell.\n";
}

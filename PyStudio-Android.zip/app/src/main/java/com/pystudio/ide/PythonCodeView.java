package com.pystudio.ide;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;

/**
 * EditText with live Python highlighting and Python-friendly indentation.
 */
public class PythonCodeView extends AppCompatEditText {

    public interface SelectionListener {
        void onSelectionChanged(int line, int column);
    }

    private boolean highlighting;
    private boolean insertingIndent;
    private boolean insertedNewline;
    private SelectionListener selectionListener;
    private Runnable textListener;

    public PythonCodeView(@NonNull Context context) {
        super(context);
        init();
    }

    public PythonCodeView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public PythonCodeView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setTypeface(Typeface.MONOSPACE);
        setHorizontallyScrolling(false);
        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                insertedNewline = false;
                if (count > before && s.length() >= start + count) {
                    insertedNewline = s.subSequence(start, start + count).toString().contains("\n");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (highlighting) {
                    return;
                }
                if (insertedNewline) {
                    insertedNewline = false;
                    maybeAutoIndent(s);
                }
                if (!insertingIndent) {
                    highlighting = true;
                    int selection = getSelectionStart();
                    PythonHighlighter.apply(s);
                    highlighting = false;
                    if (selection >= 0 && selection <= s.length()) {
                        setSelection(selection);
                    }
                    if (textListener != null) {
                        textListener.run();
                    }
                }
            }
        });
    }

    private void maybeAutoIndent(Editable editable) {
        int selection = getSelectionStart();
        if (selection <= 0 || selection > editable.length()) {
            return;
        }
        if (editable.charAt(selection - 1) != '\n') {
            return;
        }
        int lineStart = selection - 1;
        while (lineStart > 0 && editable.charAt(lineStart - 1) != '\n') {
            lineStart--;
        }
        String previousLine = editable.subSequence(lineStart, selection - 1).toString();
        int indent = 0;
        while (indent < previousLine.length() && previousLine.charAt(indent) == ' ') {
            indent++;
        }
        String trimmed = previousLine.trim();
        if (trimmed.endsWith(":")) {
            indent += 4;
        }
        if (indent <= 0) {
            return;
        }
        StringBuilder spaces = new StringBuilder(indent);
        for (int i = 0; i < indent; i++) {
            spaces.append(' ');
        }
        insertingIndent = true;
        editable.insert(selection, spaces);
        setSelection(Math.min(selection + indent, editable.length()));
        insertingIndent = false;
    }

    public void setTextListener(Runnable listener) {
        this.textListener = listener;
    }

    public void setSelectionListener(SelectionListener listener) {
        this.selectionListener = listener;
        reportSelection();
    }

    @Override
    protected void onSelectionChanged(int selStart, int selEnd) {
        super.onSelectionChanged(selStart, selEnd);
        reportSelection();
    }

    private void reportSelection() {
        if (selectionListener == null) {
            return;
        }
        Editable editable = getText();
        if (editable == null) {
            selectionListener.onSelectionChanged(1, 1);
            return;
        }
        int position = Math.max(0, Math.min(getSelectionStart(), editable.length()));
        int line = 1;
        int column = 1;
        for (int i = 0; i < position; i++) {
            if (editable.charAt(i) == '\n') {
                line++;
                column = 1;
            } else {
                column++;
            }
        }
        selectionListener.onSelectionChanged(line, column);
    }

    public void insertSnippet(String snippet) {
        int start = Math.max(0, getSelectionStart());
        int end = Math.max(start, getSelectionEnd());
        Editable editable = getText();
        if (editable == null) {
            return;
        }
        editable.replace(start, end, snippet);
        setSelection(Math.min(start + snippet.length(), editable.length()));
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_TAB) {
            Editable editable = getText();
            if (editable != null) {
                int start = Math.max(0, getSelectionStart());
                editable.insert(start, "    ");
                setSelection(Math.min(start + 4, editable.length()));
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}

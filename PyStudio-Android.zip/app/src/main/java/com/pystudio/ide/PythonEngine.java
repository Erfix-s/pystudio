package com.pystudio.ide;

import android.content.Context;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Runs Python on a single background thread. Text and images are streamed back
 * to the UI while the script is running, so long loops produce live output.
 */
public final class PythonEngine {

    public interface Listener {
        void onStdout(String text);

        void onStderr(String text);

        void onImage(String absolutePath);

        void onFinished(boolean success, long elapsedMillis);
    }

    public static final class Bridge {
        private final Listener listener;

        public Bridge(Listener listener) {
            this.listener = listener;
        }

        public void text(String text) {
            if (text != null && !text.isEmpty()) {
                listener.onStdout(text);
            }
        }

        public void error(String text) {
            if (text != null && !text.isEmpty()) {
                listener.onStderr(text);
            }
        }

        public void image(String absolutePath) {
            if (absolutePath != null && !absolutePath.isEmpty()) {
                listener.onImage(absolutePath);
            }
        }
    }

    private final Context appContext;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "pystudio-python");
        thread.setPriority(Thread.NORM_PRIORITY);
        return thread;
    });
    private final AtomicBoolean running = new AtomicBoolean(false);

    public PythonEngine(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public boolean isRunning() {
        return running.get();
    }

    public void run(String code, String fileName, Listener listener) {
        if (!running.compareAndSet(false, true)) {
            listener.onStderr("A script is already running. Wait for it to finish or restart the app.\n");
            return;
        }
        executor.execute(() -> {
            long started = System.currentTimeMillis();
            boolean success = false;
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(appContext));
                }
                Workspace.imageDir(appContext);
                File workspace = Workspace.root(appContext);
                PyObject runtime = Python.getInstance().getModule("pystudio_runtime");
                PyObject result = runtime.callAttr(
                        "run",
                        code,
                        fileName,
                        workspace.getAbsolutePath(),
                        new Bridge(listener)
                );
                success = result != null && Boolean.TRUE.equals(result.toJava(Boolean.class));
            } catch (Throwable error) {
                listener.onStderr(describeError(error));
            } finally {
                running.set(false);
                listener.onFinished(success, System.currentTimeMillis() - started);
            }
        });
    }

    private static String describeError(Throwable error) {
        StringWriter writer = new StringWriter();
        error.printStackTrace(new PrintWriter(writer));
        return "PyStudio runtime error:\n" + writer + "\n";
    }
}

package com.pystudio.ide;

import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * A compact, dependency-free Python lexer used to colour the editor.
 *
 * The scanner is a single pass over the text so a '#' inside a string is never
 * treated as a comment, and quotes inside comments are ignored.
 */
public final class PythonHighlighter {

    private static final int COLOR_TEXT = Color.rgb(232, 241, 236);
    private static final int COLOR_KEYWORD = Color.rgb(199, 146, 234);
    private static final int COLOR_BUILTIN = Color.rgb(130, 170, 255);
    private static final int COLOR_STRING = Color.rgb(195, 232, 141);
    private static final int COLOR_COMMENT = Color.rgb(101, 124, 128);
    private static final int COLOR_NUMBER = Color.rgb(247, 140, 108);
    private static final int COLOR_DEF = Color.rgb(255, 213, 128);
    private static final int COLOR_DECORATOR = Color.rgb(255, 203, 107);
    private static final int COLOR_MAGIC = Color.rgb(94, 234, 212);
    private static final int COLOR_LIBRARY = Color.rgb(125, 211, 252);

    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
            "False", "None", "True", "and", "as", "assert", "async", "await", "break",
            "class", "continue", "def", "del", "elif", "else", "except", "finally", "for",
            "from", "global", "if", "import", "in", "is", "lambda", "nonlocal", "not",
            "or", "pass", "raise", "return", "try", "while", "with", "yield", "match", "case"
    ));

    private static final Set<String> BUILTINS = new HashSet<>(Arrays.asList(
            "abs", "all", "any", "bin", "bool", "bytearray", "bytes", "callable", "chr",
            "classmethod", "compile", "complex", "dict", "dir", "divmod", "enumerate", "eval",
            "exec", "filter", "float", "format", "frozenset", "getattr", "globals", "hasattr",
            "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter",
            "len", "list", "locals", "map", "max", "memoryview", "min", "next", "object", "oct",
            "open", "ord", "pow", "print", "property", "range", "repr", "reversed", "round",
            "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super", "tuple",
            "type", "vars", "zip", "self", "cls", "Exception", "ValueError", "TypeError",
            "RuntimeError", "KeyError", "IndexError", "ImportError", "OSError", "SystemExit"
    ));

    private static final Set<String> LIBRARIES = new HashSet<>(Arrays.asList(
            "cv2", "numpy", "np", "matplotlib", "pyplot", "plt", "PIL", "Image", "pandas",
            "pd", "scipy", "requests", "bs4", "math", "random", "json", "os", "sys", "re",
            "time", "pathlib", "collections", "itertools", "platform", "threading", "asyncio"
    ));

    private PythonHighlighter() {
    }

    public static void apply(Editable editable) {
        if (editable == null) {
            return;
        }
        for (ForegroundColorSpan span : editable.getSpans(0, editable.length(), ForegroundColorSpan.class)) {
            editable.removeSpan(span);
        }
        for (StyleSpan span : editable.getSpans(0, editable.length(), StyleSpan.class)) {
            editable.removeSpan(span);
        }

        final int length = editable.length();
        if (length == 0) {
            return;
        }
        final String text = editable.toString();
        int i = 0;
        char previousSignificant = '\n';

        while (i < length) {
            char c = text.charAt(i);

            // Comments
            if (c == '#') {
                int end = text.indexOf('\n', i);
                if (end < 0) {
                    end = length;
                }
                setColor(editable, i, end, COLOR_COMMENT, true);
                i = end;
                continue;
            }

            // Strings, including prefixed and triple-quoted forms.
            if (c == '"' || c == '\'') {
                boolean triple = i + 2 < length && text.charAt(i + 1) == c && text.charAt(i + 2) == c;
                int end;
                if (triple) {
                    String delimiter = String.valueOf(c) + c + c;
                    end = text.indexOf(delimiter, i + 3);
                    end = end < 0 ? length : end + 3;
                } else {
                    int j = i + 1;
                    while (j < length) {
                        char sc = text.charAt(j);
                        if (sc == '\\') {
                            j += 2;
                            continue;
                        }
                        if (sc == c || sc == '\n') {
                            break;
                        }
                        j++;
                    }
                    end = Math.min(j + 1, length);
                }
                setColor(editable, i, end, COLOR_STRING, false);
                i = end;
                previousSignificant = 's';
                continue;
            }

            // Decorators
            if (c == '@' && (previousSignificant == '\n' || previousSignificant == ' ')) {
                int j = i + 1;
                while (j < length && (Character.isLetterOrDigit(text.charAt(j)) || text.charAt(j) == '_' || text.charAt(j) == '.')) {
                    j++;
                }
                setColor(editable, i, j, COLOR_DECORATOR, false);
                i = j;
                previousSignificant = 'd';
                continue;
            }

            // Identifiers
            if (Character.isLetter(c) || c == '_') {
                int j = i + 1;
                while (j < length && (Character.isLetterOrDigit(text.charAt(j)) || text.charAt(j) == '_')) {
                    j++;
                }
                String word = text.substring(i, j);
                boolean isDefinitionName = previousSignificant == 'f' || previousSignificant == 'c';
                if (word.length() > 4 && word.startsWith("__") && word.endsWith("__")) {
                    setColor(editable, i, j, COLOR_MAGIC, false);
                } else if (KEYWORDS.contains(word)) {
                    boolean isDef = word.equals("def") || word.equals("class");
                    setColor(editable, i, j, COLOR_KEYWORD, true);
                    previousSignificant = isDef ? (word.equals("def") ? 'f' : 'c') : 'k';
                    i = j;
                    continue;
                } else if (isDefinitionName) {
                    setColor(editable, i, j, COLOR_DEF, true);
                } else if (LIBRARIES.contains(word)) {
                    setColor(editable, i, j, COLOR_LIBRARY, false);
                } else if (BUILTINS.contains(word)) {
                    setColor(editable, i, j, COLOR_BUILTIN, false);
                }
                previousSignificant = 'i';
                i = j;
                continue;
            }

            // Numbers
            if (Character.isDigit(c)) {
                int j = i + 1;
                boolean hex = c == '0' && i + 1 < length
                        && (text.charAt(i + 1) == 'x' || text.charAt(i + 1) == 'X');
                while (j < length) {
                    char nc = text.charAt(j);
                    if (Character.isLetterOrDigit(nc) || nc == '.' || nc == '_'
                            || ((nc == '+' || nc == '-') && (text.charAt(j - 1) == 'e' || text.charAt(j - 1) == 'E'))
                            || (hex && (nc >= 'a' && nc <= 'f' || nc >= 'A' && nc <= 'F'))) {
                        j++;
                    } else {
                        break;
                    }
                }
                setColor(editable, i, j, COLOR_NUMBER, false);
                i = j;
                previousSignificant = 'n';
                continue;
            }

            if (!Character.isWhitespace(c)) {
                previousSignificant = c;
            } else if (c == '\n') {
                previousSignificant = '\n';
            }
            i++;
        }
    }

    private static void setColor(Editable editable, int start, int end, int color, boolean italic) {
        int safeStart = Math.max(0, Math.min(start, editable.length()));
        int safeEnd = Math.max(safeStart, Math.min(end, editable.length()));
        if (safeEnd <= safeStart) {
            return;
        }
        editable.setSpan(new ForegroundColorSpan(color), safeStart, safeEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (italic) {
            editable.setSpan(new StyleSpan(Typeface.ITALIC), safeStart, safeEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }
}
